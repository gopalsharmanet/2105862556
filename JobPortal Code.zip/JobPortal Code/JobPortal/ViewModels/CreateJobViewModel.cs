﻿namespace JobPortal.ViewModels;

public class CreateJobViewModel
{
}
