﻿namespace JobPortal.ViewModels
{
    public class FileResult
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public string FileName { get; set; }
        public string FilePath { get; set; }
    }
}
