﻿using JobPortal.Data;

namespace JobPortal.ViewModels
{
    public class JobApplicationDT
    {
        public int Id { get; set; }
        public string JobTitle { get; set; }
        public string Status { get; set; }
        public DateTime ApplyDate { get; set; }
        public string applyDate1 => ApplyDate.ToString("dd MMM,yyyy");
        public string JobSeekerName { get; set; }
        public string JobSeekerId { get; set; }
        public string CvUrl { get; set; }
        public string PhotoUrl { get; set; }
        public int StatusInt { get; set; }
    }
}
