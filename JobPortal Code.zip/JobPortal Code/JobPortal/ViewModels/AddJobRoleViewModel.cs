﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.ViewModels;

public class AddJobRoleViewModel
{
    public int? Id { get; set; }

    [Required]
    [StringLength(100)]
    public string JobTitle { get; set; }

    [Required]
    public string Description { get; set; }
}
