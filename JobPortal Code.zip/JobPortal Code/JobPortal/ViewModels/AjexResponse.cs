﻿namespace JobPortal.ViewModels
{
    public class AjaxResponse
    {
        public bool isSuccess { get; set; } = true;
        public int ErrorCode { get; set; } = 0;
        public string Message { get; set; }
    }

    public class AjaxResponse<TData> : AjaxResponse
    {
        public TData Data { get; set; }
    }
}
