﻿using JobPortal.Data;
using JobPortal.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations.Schema;

namespace JobPortal.ViewModels;

public class JobViewModel
{
    public int? Id { get; set; }
    public int JobProfile { get; set; }
    public string Responsibilities { get; set; }
    public int RequiredExperience { get; set; }
    public bool IsWorkFromHome { get; set; }
    public bool IsPermanent { get; set; }
    public int Budget { get; set; }
    public bool IsActive { get; set; } = true;
    public int CityId { get; set; }
    public int JobTypeId { get; set; }
    public DateTime AddDate { get; set; } = DateTime.Now;
    public DateTime LastDateToApply { get; set; } = DateTime.Now.AddDays(15);
    public int CompanyId { get; set; }
    public List<int> SelectedSkills { get; set; }
    public int JobRoleId { get; set; }
}


public class JobDT
{
    public int Id { get; set; }
    public string JobProfile { get; set; }
    public string Responsibilities { get; set; }
    public string RequiredExperience { get; set; }
    public bool IsWorkFromHome { get; set; }
    public decimal Budget { get; set; }
    public bool IsActive { get; set; }
    public string City { get; set; }
    public DateTime AddDate { get; set; }
    public DateTime LastDateToApply { get; set; }
    public string JobProvider { get; set; }
    public string Company { get; set; }
    public bool IsPermanent { get; set; }
    public string JobRole { get; set; }
}

public class JobSummary
{
    public int Id { get; set; }
    public string RequiredExperience { get; set; }
    public bool IsWorkFromHome { get; set; }
    public decimal Budget { get; set; }
    public string City { get; set; }
    public DateTime LastDateToApply { get; set; }
    public string Company { get; set; }
    public bool IsPermanent { get; set; }
    public string JobRole { get; set; }
    public IEnumerable<string> JobSkills { get; set; }
}

public class JobSearchViewModel
{
    public JobViewModel JobSearchCriteria { get; set; }
    public IEnumerable<JobSummary> Jobs { get; set; }
}