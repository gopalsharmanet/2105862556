﻿using JobPortal.Data;
using JobPortal.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.ComponentModel.DataAnnotations;

namespace JobPortal.ViewModels
{
    public class RegisterViewModel
    {
        [Required]
        [MaxLength(20, ErrorMessage = "Maximum allowed length is 20 Characters")]
        public string Name { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }
        
        [Required]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        
        [Required]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Confirm password doesn't match")]
        [Display(Name = "Confirm Password")]
        
        public string ConfirmPassword { get; set; }
        [Required]
        [Display(Name = "Register For")]
        
        public OptionsForRoles SelectedRole { get; set; }
        
        public string PhoneNumber { get; set; }

        
        [Display(Name = "City")]
        public int CurrentCityId { get; set; }
        public IEnumerable<SelectListItem> CurrentCityItems { get; set; }
        
        public IFormFile Photo { get; set; }
    }
}
