﻿using System.ComponentModel.DataAnnotations;
using JobPortal.Data;
using JobPortal.Infrastructure;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace JobPortal.ViewModels
{

    public class ProfileModel
    {
        public ChangePasswordViewModel ChangePasswordView { get; set; } = new ChangePasswordViewModel();
        public ProfileViewModel ProfileView { get; set; } = new ProfileViewModel();
        public ExperienceViewModel Experience { get; set; } = new();
        public EducationViewModel Education { get; set; } = new();
    }

    public class ProfileViewModel
    {
        public IFormFile MyProfile { get; set; }
        public string MyProfileImageSrc { get; set; }
        public string MyCVFileSrc { get; set; }
        public IFormFile MyCV { get; set; }

        public string AboutMe { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public string FullName { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public int? CurrentCityId { get; set; }
        public int? CurrentCompanyId { get; set; }
        public int CurrentJobId { get; set; }
        public LanguagesEnum CurrentLanguage { get; set; }
        public string Twitter { get; set; }
        public DateTime? DateOfBirth { get; set; }
        public string Facebook { get; set; }
        public string Instagram { get; set; }
        public string Linkedin { get; set; }
        public IEnumerable<int> SkillSets { get; set; }

        public IEnumerable<SelectListItem> CompanyListItems { get; set; }
        public IEnumerable<SelectListItem> CityListItems { get; set; }
        public IEnumerable<SelectListItem> SkillListItems { get; set; }
        public IEnumerable<SelectListItem> JobRoleListItems { get; set; }


        public IEnumerable<string> Skills { get; set; }
        public string Job { get; set; }
        public string City { get; set; }
        public string Company { get; set; }

        public IEnumerable<ExperienceViewModel> Experiences { get; set; }
        public IEnumerable<EducationViewModel> Educations { get; set; }
    }

    public class ExperienceViewModel
    {
        public int Id { get; set; }
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? StartDate { get; set; }
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? EndDate { get; set; }
        public bool IsCurrentJob { get; set; }
        public string CompanyName { get; set; }
        public string JobTitle { get; set; }

    }

    public class EducationViewModel
    {
        public int Id { get; set; }
        public string CollageName { get; set; }
        public int? Cgpa { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? StartDate { get; set; }

        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime? CompletionDate { get; set; }
        public EducationLevels EduLevel { get; set; }
    }
}
