﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.ViewModels
{
    public class CreateRoleViewModel
    {
        [Required] 
        public string Role { get; set;}
    }
}
