﻿using JobPortal.Data;
using JobPortal.Models;
using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace JobPortal.ViewModels;

public class CreateCompanyViewModel
{
    public int Id { get; set; }

    [Required]
    [MaxLength(100)]
    public string CompanyName { get; set; }
    
    [MaxLength(300)]
    public string About { get; set; }

    public int NumberOfEmployees { get; set; }
    public DateTime StartDate { get; set; }
    
    [MaxLength(200)]
    public string Address { get; set; }
    
    [Required]
    public int CityId { get; set; }
    
    [Required]
    public StatesEnum State { get; set; }

    [Required]
    [Display(Name = "Office Email")]
    [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$", ErrorMessage = "Invalid Email Format")]
    public string Email { get; set; }
    public IFormFile Logo { get; set; }
    public string LogoPath { get; set; }

    public int BusinessTypeId { get; set; }

    public IEnumerable<SelectListItem> BusinessTypeListItems { get; set; }
    public IEnumerable<SelectListItem> CityListItems { get; set; }
}

public class CompanyDT
{
    public int Id { get; set; }
    public string CompanyName { get; set; }
    public int NumberOfEmployees { get; set; }
    public DateTime StartDate { get; set; }
    public string State { get; set; }
    public string Email { get; set; }
    public string CompanyLogoPath { get; set; }
    public string BusinessType { get; set; }
    public string City { get; set; }
}

