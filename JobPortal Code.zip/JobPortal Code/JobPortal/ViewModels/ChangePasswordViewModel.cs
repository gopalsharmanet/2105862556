﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.ViewModels
{
    public class ChangePasswordViewModel
    {
        [Display(Name = "Current Password")]
        public string CurrentPassword { get; set; }
        public string NewPassword { get; set; }
        public string ReEnterPassword { get; set; }
    }
}
