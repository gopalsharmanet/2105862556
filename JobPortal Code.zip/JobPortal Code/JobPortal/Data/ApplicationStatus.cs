﻿namespace JobPortal.Data;

public enum ApplicationStatus
{
    Rejected = 0,
    Waiting = 1,
    Accepted = 2,
    Hired = 3
}
