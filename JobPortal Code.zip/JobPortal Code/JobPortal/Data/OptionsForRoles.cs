﻿namespace JobPortal.Data
{
    public enum OptionsForRoles
    {
        JobSeeker = 0,
        JobProvider = 1,
    }
}
