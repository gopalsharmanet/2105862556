﻿using Microsoft.AspNetCore.Identity;

namespace JobPortal.Data
{
    public class SiteDetail
    {
        public static string Address = "E-403 Ambika Heaven, Dindoli, Surat (Guj)";
        public static string PhoneNumber = "+91 8511871400";
        public static string Email = "Saraswat.g811@gmail.com";
    }
}
