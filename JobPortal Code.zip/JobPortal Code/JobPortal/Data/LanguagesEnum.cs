﻿namespace JobPortal.Data;

public enum LanguagesEnum
{
    None = 0,
    Hindi = 1,
    English = 2,
    Gujarati = 3,
    Marathi = 4,
    Punjabi = 5,
    Tamil = 6,
    Telugu  = 7,
}
