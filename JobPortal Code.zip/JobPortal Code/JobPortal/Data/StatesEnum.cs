﻿namespace JobPortal.Data
{
    public enum StatesEnum
    {
        None = 0,
        Gujarat = 1,
        Maharastra = 2,
        Rajasthan = 3,
        Tamilnadu = 4,
        Karnataka = 5,
        Telangana = 6
    }
}
