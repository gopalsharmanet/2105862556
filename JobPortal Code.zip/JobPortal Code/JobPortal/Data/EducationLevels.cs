﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.Data
{
    public enum EducationLevels
    {
        Secondary = 1,
        [Display(Name = "Higher Secondary")]
        HigherSecondary = 2,
        Graduation = 3,
        Master = 4,
        PhD = 5
    }
}
