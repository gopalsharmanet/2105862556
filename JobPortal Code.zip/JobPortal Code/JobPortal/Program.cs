using JobPortal.Interfaces;
using JobPortal.Models;
using JobPortal.Repositories;
using JobPortal.Services;
using JobPortal.Services.IServices;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

internal partial class Program
{
    private static void Main(string[] args)
    {
        var builder = WebApplication.CreateBuilder(args);

        // Add services to the container.

        builder.Services.AddDbContextPool<AppDbCotext>(
            options => options.UseSqlServer(builder.Configuration.GetConnectionString("JobPortalDbConnection")));

        builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
        {
            options.SignIn.RequireConfirmedPhoneNumber = false;
            options.SignIn.RequireConfirmedEmail = false;
            options.SignIn.RequireConfirmedAccount = false;
        }).AddEntityFrameworkStores<AppDbCotext>();

        builder.Services.AddScoped<ISkills, SkillsRepo>();
        builder.Services.AddScoped<ICompany, CompanyRepo>();
        builder.Services.AddScoped<ICityRepository, CityRepository>();
        builder.Services.AddScoped<IOptionService, OptionService>();
        builder.Services.AddScoped<IFileService, FileService>();

        builder.Services.AddAutoMapper(typeof(Program));
        builder.Services.AddControllersWithViews().AddRazorRuntimeCompilation();
        var app = builder.Build();

        using (var scope = app.Services.CreateScope())
        {
            DbSeeder.UserManager = scope.ServiceProvider.GetRequiredService<UserManager<ApplicationUser>>();
            DbSeeder.RoleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole>>();
            DbSeeder.SeedData().Wait();
        }

        // Configure the HTTP request pipeline.
        if (!app.Environment.IsDevelopment())
        {
            app.UseExceptionHandler("/Home/Error");
            // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
            app.UseHsts();
        }

        app.UseHttpsRedirection();
        app.UseStaticFiles();

        app.UseRouting();

        app.UseAuthentication();
        app.UseAuthorization();

        app.MapControllerRoute(
            name: "default",
            pattern: "{controller=Home}/{action=Index}/{id?}");

        app.Run();
    }
}