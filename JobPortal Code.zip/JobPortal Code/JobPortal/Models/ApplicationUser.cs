﻿using JobPortal.Data;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc.RazorPages.Infrastructure;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JobPortal.Models
{
    public class ApplicationUser : IdentityUser
    {
        public string FullName => $"{FirstName} {LastName}";

        public string FirstName { get; set; }
        public string Twitter { get; set; }
        public string Facebook { get; set; }
        public string Instagram { get; set; }
        public string LinkedIn { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string PhotoPath { get; set; }
        public bool IsBlocked { get; set; }
        public DateTime DateOfBirth { get; set; }
        public DateTime LastLogin { get; set; }

        [ForeignKey("City")]
        public int? CurrentCityId { get; set; }
        public City City { get; set; }


        [Display(Name = "Create Date")]
        public DateTime CreateDate { get; set; }

        [Display(Name = "Website Url")]
        public string WebsiteUrl { get; set; }

        [ForeignKey("Company")]
        public int? CompanyId { get; set; }
        public Company Company { get; set; }

        [ForeignKey("JobRole")]
        public int? JobRoleId { get; set; }
        public JobRole JobRole { get; set; }


        //Jobseeker 
        public string ResumePath { get; set; }
        public LanguagesEnum Languages { get; set; }

        public CV UserCV { get; set; }

        public ICollection<Feedback> Feedbacks { get; set; }
        public ICollection<BookmarkedJob> BookmarkedJobs { get; set; }
        public ICollection<JobApplication> JobApplications { get; set; }

        //Jobprovider
        public ICollection<Job> PostedJobs { get; set; }

    }
}
