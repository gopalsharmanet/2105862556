﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using JobPortal.Data;

namespace JobPortal.Models
{
    public class Company
    {
        public int Id { get; set; }
        [Required]
        [MaxLength(100)]
        public string CompanyName { get; set; }
        [MaxLength(300)]
        public string About { get; set; }
       
        public int NumberOfEmployees { get; set; }
        public DateTime StartDate { get; set; }
        [MaxLength(200)]
        public string Address { get; set; }
        [Required]
        [ForeignKey("City")]
        public int CityId { get; set; }
        public City City { get; set; }
        [Required]
        public StatesEnum State { get; set; }
        [Required]
        [Display(Name = "Office Email")]
        [RegularExpression(@"^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$",
            ErrorMessage ="Invalid Email Format")]
        public string Email { get; set; }
        public string CompanyLogoPath { get; set; }

        [ForeignKey("BusinessType")]
        public int BusinessTypeId { get; set; }
        public BusinessType BusinessType { get; set; }

        public ICollection<Job> Jobs { get; } = new List<Job>();
    }
}
