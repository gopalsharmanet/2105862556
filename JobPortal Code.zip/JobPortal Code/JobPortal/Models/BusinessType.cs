﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models
{
    public class BusinessType
    {
        public int Id { get; set; }
        [MaxLength(100)]
        [Required]
        public string Type { get; set; }
        public ICollection<Company> Companies { get; set; }
    }
}
