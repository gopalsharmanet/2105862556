﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JobPortal.Models
{
    public class BookmarkedJob
    {
        [Key]
        public int Id { get; set; }
        public DateTime SaveDate { get; set; }

        [ForeignKey("ApplicationUser")]
        public string AppUserId { get; set; }
        public ApplicationUser ApplicationUser { get; set; }

        [ForeignKey("Job")]
        public int JobId { get; set; }
        public Job Job { get; set; }
    }
}
