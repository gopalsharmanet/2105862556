﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JobPortal.Models
{
    public class Feedback
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public string Text { get; set; }
        public DateTime Addtime { get; set; }

        [ForeignKey("ApplicationUser")]
        public string AppUserId { get; set; }
        public ApplicationUser ApplicationUser { get; set; }
    }
}
