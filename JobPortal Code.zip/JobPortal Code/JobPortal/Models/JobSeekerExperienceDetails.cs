﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JobPortal.Models
{
    public class JobSeekerExperienceDetails
    {
        [Key]
        public int Id { get; set; }
        [Required]
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        [Required]
        public bool IsCurrentJob { get; set; }
        public string CompanyName { get; set; }

        [Required]
        public string JobTitle { get; set; }

        [ForeignKey("CV")]
        public int CVId { get; set; }
        public CV CV { get; set; }

    }
}
