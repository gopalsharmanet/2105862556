﻿namespace JobPortal.Models
{
    public class Skill
    {
        public int Id { get; set; }
        public string SkillName { get; set; }
        
        //Navigation for many to many CVSkillSet table (double navigation for natural mapping)
        public ICollection<Job> Jobs = new List<Job>();
        public ICollection<JobSkill> JobSkills = new List<JobSkill>();

        //Navigation for many to many CVSkillSet table (double navigation for natural mapping)
        public List<CV> CVs = new List<CV>();
        public ICollection<CVSkillSet> JobSeekerSkillSets = new List<CVSkillSet>();
    }
}
