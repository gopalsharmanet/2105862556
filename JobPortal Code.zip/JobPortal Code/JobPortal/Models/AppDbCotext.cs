﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace JobPortal.Models
{
    public class AppDbCotext : IdentityDbContext<ApplicationUser>
    {
        public AppDbCotext(DbContextOptions<AppDbCotext> options) :base(options)
        {
            
        }
        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Skill>()
                .HasMany(x => x.CVs)
                .WithMany(x => x.Skills)
                .UsingEntity<CVSkillSet>();

            builder.Entity<Skill>()
                .HasMany(x => x.Jobs)
                .WithMany(x => x.Skills)
                .UsingEntity<JobSkill>();
        }

        public DbSet<BookmarkedJob> BookmarkedJobs { get; set; }
        public DbSet<BusinessType> BusinessTypes { get; set; }
        public DbSet<JobType> JobTypes { get; set; }
        public DbSet<City> Cities { get; set; }
        public DbSet<Company> Companies { get; set; }
        public DbSet<CV> CVs { get; set; }
        public DbSet<Feedback> Feedbacks { get; set; }
        public DbSet<Job> Jobs { get; set; }
        public DbSet<JobApplication> JobApplications { get; set; }
        public DbSet<JobSeekerEducation> JobSeekerEducations { get; set; }
        public DbSet<JobSeekerExperienceDetails> ExperienceDetails { get; set; }
        public DbSet<JobSkill> JobSkills { get; set; }
        public DbSet<CVSkillSet> CVSkillSets { get; set; }
        public DbSet<Message> Messages { get; set; }    
        public DbSet<Skill> Skills { get; set; }
        public DbSet<JobRole> JobRoles { get; set; }

    }
}
