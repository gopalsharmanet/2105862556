﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JobPortal.Models;

public class CV
{
    [Key]
    public int Id { get; set; }
    public string AboutMe { get; set; }

    public ICollection<JobSeekerEducation> Education = new List<JobSeekerEducation>();

    //Navigation for many to many CVSkillSet table (double navigation for natural mapping)
    public ICollection<CVSkillSet> SkillSets = new List<CVSkillSet>();
    public ICollection<Skill> Skills = new List<Skill>();


    public ICollection<JobSeekerExperienceDetails> JobSeekerExperienceDetails = new List<JobSeekerExperienceDetails>();


    [ForeignKey("ApplicationUser")]
    public string AppUserId {  get; set; }
    public ApplicationUser ApplicationUser{ get; set; }
}
