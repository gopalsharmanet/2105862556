﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace JobPortal.Models;

public class Job
{
    [Key] 
    public int Id { get; set; }
    public string Responsibilities { get; set; }
    public int RequiredExperience { get; set; }
    public bool IsWorkFromHome { get; set; }
    public bool IsPermanent { get; set; }
    public int Budget { get; set; }
    public bool IsActive { get; set; }
    public DateTime AddDate { get; set; }
    public DateTime LastDateToApply { get; set; }
    [ForeignKey("CityId")]
    public int CityId { get; set; }
    public City City { get; set; }

    [ForeignKey("ApplicationUser")]
    public string JobProviderId { get; set; }
    public ApplicationUser ApplicationUser{ get; set; }

    [ForeignKey("Company")]
    public int CompanyId { get; set; }
    public Company Company { get; set; }

    [ForeignKey("JobType")]
    public int? JobTypeId { get; set; }
    public virtual JobType JobType { get; set; }

    [ForeignKey("JobRole")]
    [DisplayName("Job Profile")]
    public int JobRoleId { get; set; }
    public JobRole JobRole { get; set; }

    // navigation for many to many (double for more natural mapping)
    public ICollection<Skill> Skills = new List<Skill>();
    public ICollection<JobSkill> JobSkills = new List<JobSkill>();
    public ICollection<JobApplication> JobApplication = new List<JobApplication>();
}
