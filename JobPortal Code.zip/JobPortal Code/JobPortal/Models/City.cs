﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models;

public class City
{
    [Key]
    public int Id { get; set; }
    [Required]
    [StringLength(50)]
    public string CityName { get; set; }
    public bool IsActive { get; set; }

    public List<ApplicationUser> ApplicationUsers { get; set; }
    public List<Company> Companies { get; set; }
}
