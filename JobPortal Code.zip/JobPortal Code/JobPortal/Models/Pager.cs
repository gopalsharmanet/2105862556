﻿namespace JobPortal.Models;

public class Pager
{
    public int TotalPage { get; set; }
    public int StartPage { get; set; }
    public int EndPage { get; set; }

    public int TotalItems { get; set; }
    public int PageSize { get; set; }
    public int CurrentPage { get; set; }

    public Pager()
    {
        
    }

    public Pager(int totalItems,int Page, int pageSize=5)
    {
        int totalPage = (int)(totalItems / pageSize);
        int currentPage = Page;
        int startPage = currentPage - 5;
        int endPage = currentPage + 4;

        if (startPage <= 0)
        {
            startPage = 1;
            endPage = endPage - startPage + 1;
        }

        if (endPage > totalPage)
        {
            endPage = totalPage;
            if (endPage > 10)
            {
                startPage = endPage - 9;
            }
        }
        TotalPage = totalPage;
        StartPage = startPage;
        EndPage = endPage;
        TotalItems = totalItems;
        PageSize = pageSize;
        CurrentPage = CurrentPage;

    }


}

