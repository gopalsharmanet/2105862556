﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models
{
    public class JobRole
    {
        [Key]
        public int Id { get; set; }

        [Required]
        [StringLength(100)]
        public string JobTitle { get; set; }

        [Required]
        public string Description { get; set; }
    }
}
