﻿using JobPortal.Infrastructure;
using Microsoft.AspNetCore.Identity;

namespace JobPortal.Models
{
    public class DbSeeder
    {

        public static UserManager<ApplicationUser> UserManager { get; set; }
        public static RoleManager<IdentityRole> RoleManager { get; set; }
        public static async Task SeedData()
        {
            await SeedRoles(AppConst.Role_Admin, AppConst.Role_JobSeeker, AppConst.Role_JobProvider);
            await SeedUser("admin@gmail.com", AppConst.Role_Admin);
            await SeedUser("jp@gmail.com", AppConst.Role_JobProvider);
            await SeedUser("js@gmail.com", AppConst.Role_JobSeeker);
        }

        private static async Task SeedRoles(params string[] roleNames)
        {
            foreach (var roleName in roleNames)
            {
                var roleExist = await RoleManager.RoleExistsAsync(roleName);
                if (!roleExist)
                {
                    await RoleManager.CreateAsync(new IdentityRole(roleName));
                }
            }
        }

        private static async Task SeedUser(string userName, string role)
        {
            if (await UserManager.FindByEmailAsync(userName) is null)
            {
                var user = new ApplicationUser()
                {
                    UserName = userName,
                    Email = userName
                };

                var createPowerUser = await UserManager.CreateAsync(user, "Password@123");
                if (createPowerUser.Succeeded)
                {
                    await UserManager.AddToRoleAsync(user, role);
                }
            }
        }
    }
}
