﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models
{
    public class Message
    {
        [Key] 
        public int Id { get; set; }
        [Required]
        public string Text { get; set; }
        public string SenderId { get; set; }
        public string ReceiverId { get; set; }
        public DateTime SendDate { get; set; }

    }
}
