﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using JobPortal.Data;

namespace JobPortal.Models
{
    public class JobSeekerEducation
    {
        [Key]
        public int Id { get; set; }
        public string CollageName { get; set; }
        public int Cgpa { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime CompletionDate { get; set; }
        public EducationLevels EduLevel { get; set; }

        [ForeignKey("CV")]
        public int CVId { get; set; }
        public CV CV { get; set; }
    }
}
