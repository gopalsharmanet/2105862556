﻿namespace JobPortal.Models.ViewModels
{
    public class HomePageViewModel
    {
        public List<JobTypeCountViewModel> JobTypeCounts { get; set; }
        public List<JobListForIndex> JobListForIndex { get; set; }

        public HomePageViewModel()
        {
            JobTypeCounts = new List<JobTypeCountViewModel>();
            JobListForIndex = new List<JobListForIndex>();
        }
    }

    public class JobTypeCountViewModel
    {
        public string JobType { get; set; }
        public string JobTypeKey { get; set; }
        public int JobTypeCount { get; set; }
    }
}
