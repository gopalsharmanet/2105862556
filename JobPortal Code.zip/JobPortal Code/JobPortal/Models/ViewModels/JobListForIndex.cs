﻿namespace JobPortal.Models.ViewModels
{
    public class JobListForIndex
    {
        public int JobId { get; set; }
        public string CompanyLogo { get; set; }
        public string JobProfile { get; set; }
        public string City { get; set; }
        public string ProfileType { get; set; }
        public string Budget { get; set; }
        public DateTime CreatedDate { get; set; }

    }
}
