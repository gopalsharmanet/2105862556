﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models.ViewModels
{
    public class UserViewModel
    {
        public string Id { get; set; }
        public string FullName { get; set; }
        public string Email { get; set; }
        public string Mobile { get; set; }
        public bool IsBlocked { get; set; }
        public string DateOfBirth { get; set; }
        public string City { get; set; }
        public string Company { get; set; }
        public string Role { get; set; }
    }
}
