﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models.ViewModels
{
    public class CityAddEditModel
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Please enter city name.")]
        public string CityName { get; set; }
        public bool IsActive { get; set; }
    }
}
