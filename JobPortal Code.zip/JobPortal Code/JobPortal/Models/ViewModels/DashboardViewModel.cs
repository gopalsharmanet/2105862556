﻿using JobPortal.Data;
using System.ComponentModel.DataAnnotations.Schema;

namespace JobPortal.Models.ViewModels
{
    public class DashboardViewModel
    {
        public List<UserRoleViewModel> UserRoles { get; set; }
        public List<JobStauts> JobStauts { get; set; }
        public int TotalJobs { get; set; }
        public int TotalJobApplication { get; set; }
        public int TotalBookmarkedJobs { get; set; }
        public DashboardViewModel()
        {
            UserRoles = new List<UserRoleViewModel>();
            JobStauts = new List<JobStauts>();
        }
    }

    public class UserRoleViewModel
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public int NumberOfUsers { get; set; }
    }

    public class JobStauts
    {
        public string Name { get; set; }
        public int JobCount { get; set; }
    }

    public class JobApplicationViewModel
    {
        public int Id { get; set; }
        public DateTime ApplyDate { get; set; }
        public int JobId { get; set; }
        public string JobSeekerId { get; set; }
        public string AppStatus { get; set; }
        public string JobProviderId { get; set; }
    }
}
