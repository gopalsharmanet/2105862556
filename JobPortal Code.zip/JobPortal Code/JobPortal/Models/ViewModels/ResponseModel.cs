﻿namespace JobPortal.Models.ViewModels
{
    public class ResponseModel
    {
        public string Message { get; set; }
        public int Status { get; set; }
        public object Data { get; set; }
    }
}
