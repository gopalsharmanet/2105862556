﻿using System.ComponentModel.DataAnnotations;

namespace JobPortal.Models
{
    public class JobType
    {
        [Key]
        public int Id { get; set; }
        [MaxLength(100)]
        [Required]
        public string Type { get; set; }
        [MaxLength(100)]
        [Required]
        public string JobKeyWord { get; set; }
        public ICollection<Job> Jobs { get; set; }
    }
}
