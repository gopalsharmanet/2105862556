﻿namespace JobPortal.Interfaces
{
    public interface IJobs
    {

    }
}
