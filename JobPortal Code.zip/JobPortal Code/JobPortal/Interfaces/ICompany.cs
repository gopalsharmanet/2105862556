﻿using JobPortal.Models;

namespace JobPortal.Interfaces;

public interface ICompany
{
    List<Company> CompaniesList();
}
