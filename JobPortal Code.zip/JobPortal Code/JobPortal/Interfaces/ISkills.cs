﻿using JobPortal.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace JobPortal.Interfaces;

public interface ISkills
{
    List<Skill> SkillsList();
}