﻿using JobPortal.Models;
using JobPortal.Models.ViewModels;

namespace JobPortal.Interfaces;

public interface ICityRepository
{
    List<City> GetCities();
    int Save(CityAddEditModel model);
    CityAddEditModel GetCityById(int id);
    int DeleteCity(int id);
}
