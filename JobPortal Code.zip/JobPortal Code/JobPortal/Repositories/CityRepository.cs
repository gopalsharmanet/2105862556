﻿using AutoMapper;
using JobPortal.Interfaces;
using JobPortal.Models;
using JobPortal.Models.ViewModels;
using Microsoft.EntityFrameworkCore.Diagnostics;

namespace JobPortal.Repositories;

public class CityRepository : ICityRepository
{
    private readonly AppDbCotext _context;
    private readonly IMapper _mapper;

    public CityRepository(AppDbCotext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    public List<City> GetCities()
    {
        return _context.Cities.ToList();
    }

    public int Save(CityAddEditModel model)
    {
        try
        {
            if (model.Id > 0)
            {
                var city = _context.Cities.FirstOrDefault(x => x.Id == model.Id);

                if (city != null)
                {
                    //city = _mapper.Map<City>(model);
                    city.CityName = model.CityName;
                    city.IsActive = model.IsActive;
                    _context.Cities.Update(city);
                    return _context.SaveChanges();
                }
                return 0;
            }
            else
            {
                var city = _mapper.Map<City>(model);
                _context.Cities.Add(city);
                return _context.SaveChanges();
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public CityAddEditModel GetCityById(int id)
    {
        var city = _context.Cities.FirstOrDefault(x => x.Id == id);

        var cityModel = _mapper.Map<CityAddEditModel>(city);

        return cityModel;
    }

    public int DeleteCity(int id)
    {
        var city = _context.Cities.FirstOrDefault(x => x.Id == id);
        if (city != null)
        {
            _context.Cities.Remove(city);
            return _context.SaveChanges();
        }
        return 0;
    }
}
