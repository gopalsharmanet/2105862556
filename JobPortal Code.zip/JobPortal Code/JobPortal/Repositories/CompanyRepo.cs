﻿using JobPortal.Interfaces;
using JobPortal.Models;

namespace JobPortal.Repositories;

public class CompanyRepo : ICompany
{
    private readonly AppDbCotext context;

    public CompanyRepo(AppDbCotext context)
    {
        this.context = context;
    }
    public List<Company> CompaniesList()
    {
        return context.Companies.ToList();
    }
}
