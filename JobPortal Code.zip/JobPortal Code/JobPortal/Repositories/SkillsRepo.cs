﻿using JobPortal.Interfaces;
using JobPortal.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace JobPortal.Repositories
{
    public class SkillsRepo : ISkills
    {
        private readonly AppDbCotext context;

        public SkillsRepo(AppDbCotext context)
        {
            this.context = context;
        }

        public List<Skill> SkillsList()
        {
            return context.Skills.ToList();
        }
    }
}
