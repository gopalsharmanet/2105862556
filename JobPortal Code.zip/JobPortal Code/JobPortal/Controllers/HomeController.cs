﻿using JobPortal.Infrastructure;
using JobPortal.Models;
using JobPortal.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Security.Claims;

namespace JobPortal.Controllers
{
    public class HomeController : Controller
    {
        private readonly AppDbCotext context;
        private readonly RoleManager<IdentityRole> _roleManager;

        public HomeController(AppDbCotext context, RoleManager<IdentityRole> roleManager)
        {
            this.context = context;
            _roleManager = roleManager;
        }

        [Authorize]
        public IActionResult Dashboard()
        {
            DashboardViewModel dashboard = new DashboardViewModel();
            string currentUser = User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "";

            if (User.IsInRole(AppConst.Role_Admin))
            {
                var allUserRoles = context.UserRoles.ToList();
                var allRoles = _roleManager.Roles.Where(x => x.Name.ToLower() != "admin").ToList();
                dashboard.UserRoles = allRoles.Select(r => new UserRoleViewModel
                {
                    Id = r.Id,
                    Name = r.Name,
                    NumberOfUsers = allUserRoles.Where(ur => ur.RoleId == r.Id).Count()
                }).ToList();
                dashboard.TotalJobs = context.Jobs.Count();
                var appliedJob = context.JobApplications.ToList();
                dashboard.TotalJobApplication = appliedJob.Count();
                dashboard.JobStauts = appliedJob.GroupBy(x => x.AppStatus).Select(g => new JobStauts { Name = g.Key.ToString(), JobCount = g.Count() }).ToList();
            }
            else if (User.IsInRole(AppConst.Role_JobProvider))
            {

                dashboard.TotalJobs = context.Jobs.Where(x => x.JobProviderId == currentUser).Count();
                var appliedJobList = context.Jobs
                    .Join(context.JobApplications, job => job.Id, ja => ja.JobId,
                    (job, ja) => new JobApplicationViewModel
                    {
                        Id = ja.Id,
                        JobId = ja.JobId,
                        AppStatus = ja.AppStatus.ToString(),
                        ApplyDate = ja.ApplyDate,
                        JobSeekerId = ja.JobSeekerId,
                        JobProviderId = job.JobProviderId
                    }).Where(x => x.JobProviderId == currentUser).ToList();
                dashboard.TotalJobApplication = appliedJobList.Count();
                dashboard.JobStauts = appliedJobList.GroupBy(x => x.AppStatus).Select(g => new JobStauts { Name = g.Key.ToString(), JobCount = g.Count() }).ToList();
            }
            else if (User.IsInRole(AppConst.Role_JobSeeker))
            {
                dashboard.TotalJobApplication = context.JobApplications.Where(x => x.JobSeekerId == currentUser).Count();
                dashboard.TotalBookmarkedJobs = context.BookmarkedJobs.Where(x=>x.AppUserId == currentUser).Count();
                var appliedJobList = context.JobApplications.Where(x => x.JobSeekerId == currentUser).ToList();
                dashboard.JobStauts = appliedJobList.GroupBy(x => x.AppStatus).Select(g => new JobStauts { Name = g.Key.ToString(), JobCount = g.Count() }).ToList();
            }

            return View(dashboard);
        }

        [HttpGet]
        public IActionResult CreateCity()
        {
            return View();
        }

        [HttpPost]
        public IActionResult CreateCity(City model)
        {
            if (ModelState.IsValid)
            {
                var result = context.Cities.FirstOrDefault(x => x.CityName == model.CityName);
                if (result != null)
                {
                    ModelState.AddModelError(string.Empty, "City name already exists");
                    return View();
                }
                context.Cities.Add(model);
                context.SaveChanges();
                return RedirectToAction("index", "Home");
            }
            return View(model);
        }

        public IActionResult Index()
        {
            HomePageViewModel homePage = new HomePageViewModel();
            homePage.JobTypeCounts = context.JobTypes
                .Select(x => new JobTypeCountViewModel
                {
                    JobType = x.Type,
                    JobTypeCount = x.Jobs.Count(),
                    JobTypeKey = x.JobKeyWord
                }).ToList();

            homePage.JobListForIndex = context.Jobs.
                Where(x => x.LastDateToApply >= DateTime.Today).Take(20)
                .Select(x => new JobListForIndex
                {
                    JobId = x.Id,
                    JobProfile = x.JobRole.JobTitle,
                    ProfileType = x.IsPermanent ? "Permanent" : "Contractual",
                    CreatedDate = x.AddDate,
                    Budget = x.Budget.ToString(),
                    City = x.City.CityName,
                    CompanyLogo = $"companies/{ x.Company.Id.ToString() }/{ x.Company.CompanyLogoPath}"
                })
                .OrderByDescending(x => x.CreatedDate).ToList();

            return View(homePage);
        }

        public IActionResult Contact()
        {
            return View();
        }

        public IActionResult AboutUs()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}