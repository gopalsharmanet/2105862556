﻿using JobPortal.Interfaces;
using JobPortal.Models.ViewModels;
using JobPortal.Repositories;
using Microsoft.AspNetCore.Mvc;

namespace JobPortal.Controllers
{
    public class CityController : Controller
    {
        private readonly ICityRepository _cityRepository;
        public CityController(ICityRepository cityRepository)
        {
            _cityRepository = cityRepository;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GetCities()
        {
            var cities = _cityRepository.GetCities();

            return Json(new { data = cities });
        }

        public IActionResult Edit(int id)
        {
            if (id == 0)
            {
                return View("Create", new CityAddEditModel());
            }
            else
            {
                var cities = _cityRepository.GetCityById(id);
                return View("Create", cities);
            }
        }

        public IActionResult Save(CityAddEditModel model)
        {
            try
            {
                var result = _cityRepository.Save(model);
                if (result != 0)
                {
                    return Json(new ResponseModel() { Status = 1, Message = "Saved" });
                }
                else
                {
                    return Json(new ResponseModel() { Status = 2, Message = "Failed" });
                }
            }
            catch (Exception ex)
            {
                return Json(new ResponseModel() { Status = 3, Message = ex.Message });
            }
        }

        public IActionResult Delete(int id)
        {
            try
            {
                var result = _cityRepository.DeleteCity(id);
                if (result != 0)
                {
                    return Json(new ResponseModel() { Status = 1, Message = "Deleted" });
                }
                else
                {
                    return Json(new ResponseModel() { Status = 2, Message = "Failed" });
                }
            }
            catch (Exception ex)
            {
                return Json(new ResponseModel() { Status = 3, Message = ex.Message });
            }
        }
    }
}
