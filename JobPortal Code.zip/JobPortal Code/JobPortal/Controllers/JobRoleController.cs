﻿using JobPortal.Infrastructure;
using JobPortal.Models;
using JobPortal.Models.ViewModels;
using JobPortal.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace JobPortal.Controllers
{
    public class JobRoleController : Controller
    {
        private readonly AppDbCotext _context;

        public JobRoleController(AppDbCotext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GetAllJobRole(DtParameters dtParameters)
        {
            var searchBy = dtParameters.Search?.Value;

            var orderCriteria = "Id";
            var orderAscendingDirection = true;

            if (dtParameters.Order != null)
            {
                orderCriteria = dtParameters.Columns[dtParameters.Order[0].Column].Data;
                orderAscendingDirection = dtParameters.Order[0].Dir.ToString().ToLower() == "asc";
            }

            var result = _context.JobRoles.AsQueryable();

            if (!string.IsNullOrEmpty(searchBy))
            {
                result = result.Where(r =>
                    r.JobTitle != null && r.JobTitle.ToUpper().Contains(searchBy.ToUpper())
                //|| r.FirstSurname != null && r.FirstSurname.ToUpper().Contains(searchBy.ToUpper())
                //|| r.SecondSurname != null && r.SecondSurname.ToUpper().Contains(searchBy.ToUpper())
                //|| r.Street != null && r.Street.ToUpper().Contains(searchBy.ToUpper()) 
                );
            }

            result = orderAscendingDirection ? result.OrderByDynamic(orderCriteria, DtOrderDir.Asc) : result.OrderByDynamic(orderCriteria, DtOrderDir.Desc);

            // now just get the count of items (without the skip and take) - eg how many could be returned with filtering
            var filteredResultsCount = await result.CountAsync();
            var totalResultsCount = await _context.Skills.CountAsync();

            return Json(new DtResult<JobRole>
            {
                Draw = dtParameters.Draw,
                RecordsTotal = totalResultsCount,
                RecordsFiltered = filteredResultsCount,
                Data = await result
                    .Skip(dtParameters.Start)
                    .Take(dtParameters.Length)
                    .ToListAsync()
            });
        }

        [HttpPost]
        public IActionResult SaveJobRole(JobRoleViewModel model)
        {

            var response = new AjaxResponse() { isSuccess = true, Message = "JobRole created successfully" };
            if (ModelState.IsValid)
            {
                if (model.Id is not null)
                {
                    if (_context.JobRoles.Any(x => x.Id == model.Id))
                    {
                        _context.Entry(model).State = EntityState.Modified;
                        _context.SaveChanges();
                        response.Message = "Jobrole updated successfully";
                    }
                    else
                    {
                        response.isSuccess = false;
                        response.Message = $"Job role with id = {model.Id} not found";
                        return Json(response);
                    }
                }
                else
                {
                    var roleExists = _context.JobRoles.Any(x => x.JobTitle.ToLower() == model.JobTitle.ToLower());
                    if (!roleExists)
                    {
                        JobRole jobRole = new JobRole()
                        {
                            Description = model.Description,
                            JobTitle = model.JobTitle
                        };
                        _context.JobRoles.Add(jobRole);
                        _context.SaveChanges();
                    }
                    else
                    {
                        response.isSuccess = false;
                        response.Message = $"Job role {model.JobTitle} already exists";
                    }
                }
                return Json(response);
            }
            return Json(new AjaxResponse { isSuccess = false, Message = "Invalid Model State" });
            //return RedirectToAction("Index");
        }

        [HttpDelete]
        public IActionResult DeleteJobRole(int id)
        {
            var response = new AjaxResponse
            {
                isSuccess = true,
                Message = "Job Role Deleted!"
            };
            if (ModelState.IsValid)
            {
                if (_context.Skills.FirstOrDefault(x => x.Id == id) is Skill skill)
                {
                    _context.Skills.Remove(skill);
                    _context.SaveChanges();
                }
                else
                {
                    response.isSuccess = false;
                    response.Message = "Job Role exists in database!";
                    return Json(response);
                }
            }
            return Json(response);
        }

    }
}
