﻿using JobPortal.Models;
using JobPortal.Models.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace JobPortal.Controllers
{
    public class UserController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly AppDbCotext _context;
        public UserController(UserManager<ApplicationUser> userManager, AppDbCotext context)
        {
            this.userManager = userManager;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult ListUsers()
        {
            var UserList = _context.Users
                .Join(_context.UserRoles, user => user.Id, userrole => userrole.UserId, (user, userrole) => new { user, userrole })
                .Join(_context.Roles, ur => ur.userrole.RoleId, roles => roles.Id, (ur, roles) => new { ur, roles })
                .Select(x =>
                new UserViewModel
                {
                    Id = x.ur.user.Id,
                    FullName = $"{x.ur.user.FirstName} {x.ur.user.LastName}",
                    Email = x.ur.user.Email,
                    Mobile = x.ur.user.PhoneNumber,
                    City = x.ur.user.City.CityName,
                    Company = x.ur.user.Company.CompanyName,
                    DateOfBirth = x.ur.user.DateOfBirth.ToString("dd-MM-yyyy"),
                    IsBlocked = x.ur.user.IsBlocked,
                    Role = x.roles.Name
                }).Where(x => x.Role != "Admin");
            return Json(new { data = UserList });
        }

        public IActionResult GetUserbyId(string id)
        {
            var user = userManager.FindByIdAsync(id);
            return Json(user);
        }

        public IActionResult Create()
        {

            return View();
        }
    }
}
