﻿using JobPortal.Infrastructure;
using JobPortal.Models;
using JobPortal.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace JobPortal.Controllers
{
    public class SkillController : Controller
    {
        private readonly AppDbCotext _context;

        public SkillController(AppDbCotext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            return View(new Skill());
        }

        [HttpPost]
        public async Task<IActionResult> GetAllSkill(DtParameters dtParameters)
        {
            var searchBy = dtParameters.Search?.Value;

            // if we have an empty search then just order the results by Id ascending
            var orderCriteria = "Id";
            var orderAscendingDirection = true;

            if (dtParameters.Order != null)
            {
                // in this example we just default sort on the 1st column
                orderCriteria = dtParameters.Columns[dtParameters.Order[0].Column].Data;
                orderAscendingDirection = dtParameters.Order[0].Dir.ToString().ToLower() == "asc";
            }

            var result = _context.Skills.AsQueryable();

            if (!string.IsNullOrEmpty(searchBy))
            {
                result = result.Where(r =>
                    r.SkillName != null && r.SkillName.ToUpper().Contains(searchBy.ToUpper())
                //|| r.FirstSurname != null && r.FirstSurname.ToUpper().Contains(searchBy.ToUpper())
                //|| r.SecondSurname != null && r.SecondSurname.ToUpper().Contains(searchBy.ToUpper())
                //|| r.Street != null && r.Street.ToUpper().Contains(searchBy.ToUpper()) 
                );
            }

            result = orderAscendingDirection ? result.OrderByDynamic(orderCriteria, DtOrderDir.Asc) : result.OrderByDynamic(orderCriteria, DtOrderDir.Desc);

            // now just get the count of items (without the skip and take) - eg how many could be returned with filtering
            var filteredResultsCount = await result.CountAsync();
            var totalResultsCount = await _context.Skills.CountAsync();

            return Json(new DtResult<Skill>
            {
                Draw = dtParameters.Draw,
                RecordsTotal = totalResultsCount,
                RecordsFiltered = filteredResultsCount,
                Data = await result
                    .Skip(dtParameters.Start)
                    .Take(dtParameters.Length)
                    .ToListAsync()
            });
        }

        [HttpPost]
        public IActionResult SaveSkill(Skill model)
        {
            var response = new AjaxResponse<string>
            {
                isSuccess = true,
                Message = "Skill Updated!"
            };

            if (ModelState.IsValid)
            {
                if (_context.Skills.FirstOrDefault(x => x.Id == model.Id) is Skill skill)
                {
                    skill.SkillName = model.SkillName;
                    _context.Skills.Update(skill);
                    response.Data = skill.SkillName;
                    _context.SaveChanges();
                    return Json(response);
                }
                else
                {
                    if (!_context.Skills.Any(x => x.SkillName == model.SkillName))
                    {
                        _context.Skills.Add(model);
                        _context.SaveChanges();
                    }
                    else
                    {
                        response.isSuccess = false;
                        response.Message = $"Skill with name {model.SkillName} already exists";
                        return Json(response);
                    }
                }
            }
            return RedirectToAction("Index");
        }

        [HttpPost]
        public IActionResult DeleteSkill(int id)
        {
            var response = new AjaxResponse<string>
            {
                isSuccess = true,
                Message = "Skill Deleted!"
            };
            if (ModelState.IsValid)
            {
                if (_context.Skills.FirstOrDefault(x => x.Id == id) is Skill skill)
                {
                    _context.Skills.Remove(skill);
                    _context.SaveChanges();
                }
                else
                {
                    response.isSuccess = false;
                    response.Message = "Skill not exists in database";
                    return Json(response);
                }
            }
            return Json(response);
        }
    }
}
