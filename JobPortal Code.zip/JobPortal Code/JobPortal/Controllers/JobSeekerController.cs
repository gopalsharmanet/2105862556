﻿using AutoMapper;
using JobPortal.Data;
using JobPortal.Infrastructure;
using JobPortal.Models;
using JobPortal.Services.IServices;
using JobPortal.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace JobPortal.Controllers
{

    [Authorize(Roles = AppConst.Role_JobSeeker)]
    public class JobSeekerController : Controller
    {

        private int CurrentUserCVId
        {
            get => Convert.ToInt32(TempData.Peek(AppConst.Temp_UserCVId) ?? 0);
            set
            {
                TempData[AppConst.Temp_UserCVId] = value;
                TempData.Keep(AppConst.Temp_UserCVId);
            }
        }
        private readonly AppDbCotext _context;
        private readonly IOptionService _optionManager;
        private readonly IFileService _fileManager;
        private readonly IMapper _mapper;


        public JobSeekerController(AppDbCotext context, IOptionService optionManager, IFileService fileManager, IMapper mapper)
        {
            _context = context;
            _optionManager = optionManager;
            _fileManager = fileManager;
            _mapper = mapper;
        }

        public IActionResult Index()
        {
            return View();
        }

        public async Task<IActionResult> Profile()
        {
            var model = new ProfileModel();
            var user = await _context.Users
                .Include(a => a.JobRole)
                .Include(a => a.City)
                .Include(a => a.Company)
                .Include(a => a.UserCV)
                    .ThenInclude(a => a.Skills)
                .FirstAsync(a => a.Id == User.GetUserId());

            if (user.UserCV == null)
            {
                await _context.CVs.AddAsync(new CV()
                {
                    AppUserId = User.GetUserId(),
                });
                await _context.SaveChangesAsync();
            }

            var educations = await _context.JobSeekerEducations.Where(a => a.CVId == user.UserCV.Id).OrderByDescending(a => a.EduLevel).ToListAsync();
            var experienceDetails = await _context.ExperienceDetails.Where(a => a.CVId == user.UserCV.Id).OrderByDescending(a => a.IsCurrentJob).ToListAsync();

            var profile = new ProfileViewModel
            {
                SkillListItems = _optionManager.GetAllSkills(),
                CityListItems = _optionManager.GetAllCities(),
                CompanyListItems = _optionManager.GetAllCompanies(),
                JobRoleListItems = _optionManager.GetAllJobRoles(),
                MyCVFileSrc = _fileManager.GetUserCV(user),
                MyProfileImageSrc = _fileManager.GetUserProfile(user),
                SkillSets = user.UserCV.Skills.Select(a => a.Id),
                Skills = user.UserCV.Skills.Select(a => a.SkillName),
                City = user.City.CityName,
                Job = user.JobRole?.JobTitle,
                Company = user.Company?.CompanyName,
                Experiences = _mapper.Map<List<ExperienceViewModel>>(experienceDetails),
                Educations = _mapper.Map<List<EducationViewModel>>(educations)
            };

            _mapper.Map(user, profile);

            model.ProfileView = profile;


            CurrentUserCVId = user.UserCV.Id;
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Profile(ProfileViewModel model)
        {
            var cv = await _context.CVs.FirstAsync(cv => cv.Id == CurrentUserCVId);
            var user = await _context.Users.FirstOrDefaultAsync(cv => cv.Id == User.GetUserId());
            var skillSets = await _context.CVSkillSets.AsNoTracking().Where(cv => cv.CVId == CurrentUserCVId).ToListAsync();
            var existingSkillIds = skillSets.Select(a => a.SkillId);
            var needToDeleteSkillIds = existingSkillIds.Except(model.SkillSets);

            var needToAddSkills = model.SkillSets.Where(a => !existingSkillIds.Contains(a)).Select(skillId => new CVSkillSet
            {
                CVId = CurrentUserCVId,
                SkillId = skillId
            });

            var needToRemoveSkills = skillSets.Where(s => needToDeleteSkillIds.Contains(s.SkillId));

            cv.AboutMe = model.AboutMe;
            user.CompanyId = model.CurrentCompanyId;

            _mapper.Map(model, user);

            await _fileManager.UploadUserProfileAsync(model.MyProfile, user);
            await _fileManager.UploadUserCVAsync(model.MyCV, user);

            if (needToAddSkills.Any())
            {
                await _context.CVSkillSets.AddRangeAsync(needToAddSkills);
            }

            if (needToRemoveSkills.Any())
            {
                _context.RemoveRange(needToRemoveSkills);
                //foreach (var skillToRemove in needToRemoveSkills)
                //{
                //    _context.Entry(skillToRemove).State = EntityState.Detached;
                //    _context.Remove(skillToRemove);
                //}

            }

            await _context.SaveChangesAsync();

            return RedirectToAction("Profile");
        }

        [HttpPost]
        public async Task<IActionResult> SaveEducation(EducationViewModel model)
        {
            var educations = await _context.JobSeekerEducations.Where(a => a.CVId == CurrentUserCVId).ToListAsync();


            var education = _mapper.Map<JobSeekerEducation>(model);
            education.CVId = CurrentUserCVId;

            if (model.Id > 0)
            {
                if (educations.Any(a => a.Id == model.Id))
                {
                    _context.JobSeekerEducations.Update(education);
                }
                else
                {
                    return NotFound(model.Id);
                }
            }
            else
            {
                await _context.JobSeekerEducations.AddAsync(education);
            }
            await _context.SaveChangesAsync();
            return RedirectToAction("Profile");
        }

        [HttpPost]
        public async Task<IActionResult> SaveExperience(ExperienceViewModel model)
        {
            var experienceDetails = await _context.ExperienceDetails.Where(a => a.CVId == CurrentUserCVId).ToListAsync();

            var experience = _mapper.Map<JobSeekerExperienceDetails>(model);


            if (experienceDetails.FirstOrDefault(a => a.Id != 0 && a.Id != model.Id && a.IsCurrentJob) is JobSeekerExperienceDetails existsCurrentJob)
            {
                existsCurrentJob.IsCurrentJob = false;
            }

            experience.CVId = CurrentUserCVId;

            if (model.Id > 0)
            {
                if (experienceDetails.Any(a => a.Id == model.Id))
                {
                    var existingExperience = _context.ExperienceDetails.Find(experience.Id);
                    _context.Entry(existingExperience).CurrentValues.SetValues(experience);

                }
                else
                {
                    return NotFound(model.Id);
                }
            }
            else
            {
                await _context.ExperienceDetails.AddAsync(experience);
            }
            await _context.SaveChangesAsync();
            return RedirectToAction("Profile");
        }


        [HttpDelete]
        public async Task<IActionResult> DeleteExperience(int id)
        {
            var response = new AjaxResponse();
            var experience = await _context.ExperienceDetails.FirstOrDefaultAsync(a => a.CVId == CurrentUserCVId && a.Id == id);

            if (experience != null)
            {
                response.isSuccess = true;
                _context.ExperienceDetails.Remove(experience);
                await _context.SaveChangesAsync();
                response.Message = "Deleted!";
            }
            else
            {
                response.isSuccess = false;
                response.Message = "Not Found!";
            }

            return Ok(response);
        }

        [HttpDelete]
        public async Task<IActionResult> DeleteEducation(int id)
        {
            var response = new AjaxResponse();
            var education = await _context.JobSeekerEducations.FirstOrDefaultAsync(a => a.CVId == CurrentUserCVId && a.Id == id);

            if (education != null)
            {
                response.isSuccess = true;
                _context.JobSeekerEducations.Remove(education);
                await _context.SaveChangesAsync();
                response.Message = "Deleted!";
            }
            else
            {
                response.isSuccess = false;
                response.Message = "Not Found!";
            }

            return Ok(response);
        }

        public IActionResult AppliedJobs()
        {
            var jobApplications = _context.JobApplications
                .Include(ja => ja.Job)
                    .ThenInclude(j => j.Company)
                .Include(ja => ja.Job)
                    .ThenInclude(j => j.JobRole)
                .Include(ja => ja.Job)
                    .ThenInclude(j => j.Skills)
                .Where(a => a.JobSeekerId == User.GetUserId());

            var jobs = _mapper.Map<List<JobSummary>>(jobApplications.Select(a => a.Job));

            return View(jobs);
        }
        public IActionResult BookmarkedJobs()
        {
            var bookmarkedJobs = _context.BookmarkedJobs
                .Include(ja => ja.Job)
                    .ThenInclude(j => j.Company)
                .Include(ja => ja.Job)
                    .ThenInclude(j => j.JobRole)
                .Include(ja => ja.Job)
                    .ThenInclude(j => j.Skills)
                .Where(a => a.AppUserId == User.GetUserId());

            var jobs = _mapper.Map<List<JobSummary>>(bookmarkedJobs.Select(a => a.Job));

            return View(jobs);
        }
    }
}
