﻿using AutoMapper;
using JobPortal.Infrastructure;
using JobPortal.Interfaces;
using JobPortal.Models;
using JobPortal.Repositories;
using JobPortal.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;

namespace JobPortal.Controllers;

public class JobController : Controller
{
    private readonly AppDbCotext context;
    private readonly UserManager<ApplicationUser> userManager;
    private readonly SignInManager<ApplicationUser> signInManager;
    private readonly ISkills skills;
    private readonly ICompany company;
    private readonly IMapper _mapper;

    public JobController(AppDbCotext context,
                            UserManager<ApplicationUser> userManager,
                            SignInManager<ApplicationUser> signInManager,
                            ISkills skills,
                            ICompany company,
                            IMapper mapper)
    {
        this.context = context;
        this.userManager = userManager;
        this.signInManager = signInManager;
        this.skills = skills;
        this.company = company;
        _mapper = mapper;
    }


    [HttpGet]
    public IActionResult Index()
    {
        return View();
    }

    [HttpGet]
    public IActionResult CreateJob()
    {
        JobViewModel model = new()
        {
            SelectedSkills = new List<int>()
        };
        ViewBag.JobRolesList = context.JobRoles.ToList();
        ViewBag.SkillsList = context.Skills.ToList();
        ViewBag.CompaniesList = GetCompanies();
        ViewBag.CitiesList = context.Cities.ToList();
        ViewBag.JobTypeList = context.JobTypes.ToList();
        return View(model);
    }

    [HttpPost]
    public IActionResult CreateJob(JobViewModel model)
    {
        ViewBag.SkillsList = context.Skills.OrderBy(x => x.Id).ToList();
        ViewBag.CompaniesList = GetCompanies();
        ViewBag.CitiesList = context.Cities;
        ViewBag.JobRolesList = context.JobRoles.ToList();

        if (ModelState.IsValid)
        {
            var jobPostedById = userManager.GetUserId(User);

            Job job = new()
            {
                JobRoleId = model.JobRoleId,
                Responsibilities = model.Responsibilities,
                RequiredExperience = model.RequiredExperience,
                IsWorkFromHome = model.IsWorkFromHome,
                IsPermanent = model.IsPermanent,
                Budget = model.Budget,
                IsActive = model.IsActive,
                CityId = model.CityId,
                JobTypeId = model.JobTypeId,
                AddDate = model.AddDate,
                LastDateToApply = model.LastDateToApply,
                CompanyId = model.CompanyId,
                JobProviderId = userManager.GetUserId(User)
            };
            if (model.Id != null)
            {
                job.Id = model.Id.Value;
                var jobSkill = context.JobSkills.Where(x => x.JobId == job.Id);
                context.JobSkills.RemoveRange(jobSkill);
                context.Jobs.Update(job);

            }
            else
            {
                context.Jobs.Add(job);
            }
            context.SaveChanges();
            var jobId = job.Id;
            foreach (var skill in model.SelectedSkills)
            {
                job.JobSkills.Add(new JobSkill
                {
                    JobId = jobId,
                    SkillId = skill,
                });
            }
            context.JobSkills.AddRange(job.JobSkills);
            context.SaveChanges();
            return RedirectToAction("ListJobs", "Job");
        }
        return View(model);
    }

    [HttpGet]
    public IActionResult Edit(int id)
    {
        JobViewModel model = new()
        {
            SelectedSkills = new List<int>()
        };
        var jobModel = context.Jobs.FirstOrDefault(x => x.Id == id);
        model = _mapper.Map<JobViewModel>(jobModel);
        model.SelectedSkills = context.JobSkills.Where(x => x.JobId == id)?.Select(x => x.SkillId).ToList() ?? new List<int>();
        ViewBag.JobRolesList = context.JobRoles.ToList();
        ViewBag.SkillsList = context.Skills.ToList();
        ViewBag.CompaniesList = GetCompanies();
        ViewBag.CitiesList = context.Cities.ToList();
        ViewBag.JobTypeList = context.JobTypes.ToList();
        return View("createjob", model);
    }

    private List<SelectListItem> GetSkills()
    {
        var listSkills = new List<SelectListItem>();
        List<Skill> skill = skills.SkillsList();

        listSkills = skill.Select(x => new SelectListItem()
        {
            Value = x.Id.ToString(),
            Text = x.SkillName

        }).ToList();

        var defItem = new SelectListItem()
        {
            Value = "",
            Text = "----Select Skills----"
        };
        listSkills.Insert(0, defItem);
        return listSkills;
    }

    private List<SelectListItem> GetCompanies()
    {
        var compList = new List<SelectListItem>();
        List<Company> companies = company.CompaniesList();

        compList = companies.Select(x => new SelectListItem()
        {
            Value = x.Id.ToString(),
            Text = x.CompanyName
        }).ToList();

        var defItem = new SelectListItem()
        {
            Value = "",
            Text = "----Select Company----"
        };

        compList.Insert(0, defItem);
        return compList;
    }

    [HttpGet]
    public IActionResult ListJobs(int pge = 1)
    {
        List<Job> listedJobs = new List<Job>();
        if (signInManager.IsSignedIn(User) && (User.IsInRole(AppConst.Role_JobSeeker) || User.IsInRole(AppConst.Role_JobProvider)))
            listedJobs = context.Jobs
                .OrderByDescending(x => x.Id)
                .Include(x => x.JobRole)
                .Where(x => x.JobProviderId == User.GetUserId()).ToList();
        else
            listedJobs = context.Jobs
                .OrderByDescending(x => x.Id)
                .Include(x => x.JobRole).ToList();

        const int pageSize = 10;
        int totalItems = listedJobs.Count;
        var pager = new Pager(totalItems, pge, pageSize);
        int recSkip = (pge - 1) * pageSize;
        var data = listedJobs.Skip(recSkip).Take(pageSize).ToList();
        ViewBag.Pager = pager;
        return View(data);
    }

    #region Job Search

    public IActionResult JobSearch()
    {
        var jobSearch = new JobSearchViewModel();

        var job = context.Jobs
            .Include(j => j.Company)
            .Include(j => j.JobRole)
            .Include(j => j.Skills)
            .ToList();

        jobSearch.Jobs = _mapper.Map<List<JobSummary>>(job);

        return View(jobSearch);
    }

    [HttpPost]
    public IActionResult JobSearch(JobViewModel model)
    {
        var jobSearch = new JobSearchViewModel();

        jobSearch.JobSearchCriteria = model;

        var query = context.Jobs
            .Include(j => j.Company)
            .Include(j => j.JobRole)
            .Include(j => j.Skills)
            .Where(j =>
            (model.JobRoleId == 0 || j.JobRoleId == model.JobRoleId) &&
            (model.CompanyId == 0 || j.CompanyId == model.CompanyId) &&
            (model.CityId == 0 || j.CityId == model.CityId) &&
            (model.RequiredExperience == 0 || j.RequiredExperience <= model.RequiredExperience) &&
            (model.Budget == 0 || j.Budget >= model.Budget) &&
            (model.SelectedSkills == null || model.SelectedSkills.Any(selectedSkillId => j.JobSkills.Any(js => js.SkillId == selectedSkillId))) &&
            (model.IsPermanent == false || j.IsPermanent == model.IsPermanent) &&
            (model.IsWorkFromHome == false || j.IsWorkFromHome == model.IsWorkFromHome)).ToList();

        var job = query.ToList();


        jobSearch.Jobs = _mapper.Map<List<JobSummary>>(job);



        return View(jobSearch);
    }

    #endregion Job Search

    [HttpPost]
    public IActionResult ApplyForJob(int jobId)
    {
        var response = new AjaxResponse();
        if (context.JobApplications.FirstOrDefault(a => a.JobId == jobId && a.JobSeekerId == User.GetUserId()) is JobApplication application)
        {
            response.isSuccess = false;
            response.Message = "You have already applied for this job.";
        }
        else
        {
            response.isSuccess = true;
            response.Message = "Application submitted successfully.";
            context.JobApplications.Add(new()
            {
                JobSeekerId = User.GetUserId(),
                ApplyDate = DateTime.Now,
                AppStatus = Data.ApplicationStatus.Waiting,
                JobId = jobId,
            });
            context.SaveChanges();
        }
        return Ok(response);
    }

    [HttpPost]
    public IActionResult BookmarkeJob(int jobId)
    {
        var response = new AjaxResponse();
        if (context.BookmarkedJobs.FirstOrDefault(a => a.JobId == jobId && a.AppUserId == User.GetUserId()) is BookmarkedJob bookmarkedJob)
        {
            response.isSuccess = false;
            response.Message = "You have already Bookmarked for this job.";
        }
        else
        {
            response.isSuccess = true;
            response.Message = "Application Bookmarked.";
            context.BookmarkedJobs.Add(new()
            {
                AppUserId = User.GetUserId(),
                SaveDate = DateTime.Now,
                JobId = jobId,
            });
            context.SaveChanges();
        }
        return Ok(response);
    }
    [HttpPost]
    public IActionResult MessageForJob(int jobId)
    {
        var response = new AjaxResponse();
        response.isSuccess = true;
        response.Message = "Application Bookmarked.";
        context.BookmarkedJobs.Add(new()
        {
            AppUserId = User.GetUserId(),
            SaveDate = DateTime.Now,
            JobId = jobId,
        });
        context.SaveChanges();
        return Ok(response);
    }
}
