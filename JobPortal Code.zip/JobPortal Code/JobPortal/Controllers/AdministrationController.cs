﻿using AutoMapper;
using JobPortal.Infrastructure;
using JobPortal.Models;
using JobPortal.Repositories;
using JobPortal.Services;
using JobPortal.Services.IServices;
using JobPortal.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting.Internal;

namespace JobPortal.Controllers;

public class AdministrationController : Controller
{
    private readonly AppDbCotext _context;
    private readonly RoleManager<IdentityRole> _roleManager;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly IWebHostEnvironment _environment;
    private readonly IMapper _mapper;
    private readonly IFileService _fileService;
    private readonly IOptionService _optionService;

    public AdministrationController(AppDbCotext context,
                                    RoleManager<IdentityRole> roleManager,
                                    UserManager<ApplicationUser> userManager,
                                    IWebHostEnvironment hostingEnvironment,
                                    IMapper mapper,
                                    IFileService fileService,
                                    IOptionService optionService)
    {
        _context = context;
        _roleManager = roleManager;
        _userManager = userManager;
        _environment = hostingEnvironment;
        _mapper = mapper;
        _fileService = fileService;
        _optionService = optionService;
    }
    public IActionResult Index()
    {
        return View();
    }

    public IActionResult Profile()
    {
        return View();
    }

    [HttpGet]
    public IActionResult CreateRole()
    {
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> CreateRole(CreateRoleViewModel model)
    {
        if (ModelState.IsValid)
        {
            IdentityRole role = new()
            {
                Name = model.Role
            };

            var result = await _roleManager.CreateAsync(role);
            if (result.Succeeded)
            {
                return RedirectToAction("ListRoles", "Administration");
            }

            foreach (IdentityError error in result.Errors)
            {
                ModelState.AddModelError(string.Empty, error.Description);
            }
        }
        return View(model);

    }

    [HttpGet]
    public IActionResult ListRoles()
    {
        var RoleList = _roleManager.Roles;
        return View(RoleList);
    }

    [HttpGet]
    public async Task<IActionResult> EditRole(string id)
    {
        var role = await _roleManager.FindByIdAsync(id);

        if (role == null)
        {
            ViewBag.ErrorMessage = $"Role with Id = {id} cannot be found";
            return View("NotFound");
        }

        var model = new EditRoleViewModel
        {
            RoleId = role.Id,
            RoleName = role.Name
        };

        foreach (var user in _userManager.Users.ToList())
        {
            if (await _userManager.IsInRoleAsync(user, role.Name))
            {
                model.Users.Add(user.UserName);
            }
        }

        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> EditRole(EditRoleViewModel model)
    {
        var role = await _roleManager.FindByIdAsync(model.RoleId);
        if (role == null)
        {
            ViewBag.ErrorMsg = "Request role not found";
            return View("NotFound");
        }
        role.Name = model.RoleName;

        var result = await _roleManager.UpdateAsync(role);
        if (result.Succeeded)
        {
            return RedirectToAction("ListRoles");
        }
        return View(model);
    }

    [HttpPost]
    public async Task<IActionResult> DeleteRole(string id)
    {
        var role = await _roleManager.FindByIdAsync(id);
        if (role == null)
        {
            ViewBag.ErrorMsg = $"Role with Id = {id} not found";
            return View("NotFound");
        }
        var result = await _roleManager.DeleteAsync(role);
        if (result.Succeeded)
        {
            return RedirectToAction("ListRoles", "Administrator");
        }
        return View();
    }

    [HttpGet]
    public IActionResult ListUsers()
    {
        var UserList = _userManager.Users;
        return View(UserList);
    }

    #region ManageCompany

    [HttpGet]
    public IActionResult ManageCompany()
    {
        //ViewBag.BusinessType = _context.BusinessTypes.OrderBy(x => x.Type).ToList();
        return View();
    }

    [HttpPost]
    public async Task<IActionResult> GetAllCompany(DtParameters dtParameters)

    {
        var searchBy = dtParameters.Search?.Value;

        // if we have an empty search then just order the results by Id ascending
        var orderCriteria = "Id";
        var orderAscendingDirection = true;

        if (dtParameters.Order != null)
        {
            // in this example we just default sort on the 1st column
            orderCriteria = dtParameters.Columns[dtParameters.Order[0].Column].Data;
            orderAscendingDirection = dtParameters.Order[0].Dir.ToString().ToLower() == "asc";
        }

        var result = _context.Companies
            .Include(c => c.BusinessType)
            .Include(x => x.City)
            .AsQueryable();

        if (!string.IsNullOrEmpty(searchBy))
        {
            result = result.Where(r =>
                r.CompanyName != null && r.CompanyName.ToUpper().Contains(searchBy.ToUpper())
            //|| r.FirstSurname != null && r.FirstSurname.ToUpper().Contains(searchBy.ToUpper())
            //|| r.SecondSurname != null && r.SecondSurname.ToUpper().Contains(searchBy.ToUpper())
            //|| r.Street != null && r.Street.ToUpper().Contains(searchBy.ToUpper()) 
            );
        }

        result = orderAscendingDirection ? result.OrderByDynamic(orderCriteria, DtOrderDir.Asc) : result.OrderByDynamic(orderCriteria, DtOrderDir.Desc);

        // now just get the count of items (without the skip and take) - eg how many could be returned with filtering
        var filteredResultsCount = await result.CountAsync();
        var totalResultsCount = await _context.Companies.CountAsync();

        var filteredCompanies = await result.Skip(dtParameters.Start).Take(dtParameters.Length).ToListAsync();
        filteredCompanies.ForEach(c =>
        {
            c.CompanyLogoPath = _fileService.GetCompanyLogo(c);
        });
        var data = _mapper.Map<List<CompanyDT>>(filteredCompanies);
        return Json(new DtResult<CompanyDT>
        {
            Draw = dtParameters.Draw,
            RecordsTotal = totalResultsCount,
            RecordsFiltered = filteredResultsCount,
            Data = data
        });

    }

    [HttpGet]
    public IActionResult GetCompanyView()
    {
        var model = new CreateCompanyViewModel
        {
            BusinessTypeListItems = _optionService.GetAllBusinessTypes(),
            CityListItems = _optionService.GetAllCities()
        };
        return PartialView(PartialViewConst.SaveCompany, model);
    }

    [HttpGet]
    public async Task<IActionResult> GetCompanyById(int id)
    {
        var model = new CreateCompanyViewModel
        {
            BusinessTypeListItems = _optionService.GetAllBusinessTypes(),
            CityListItems = _optionService.GetAllCities()
        };

        if (await _context.Companies.FirstOrDefaultAsync(x => x.Id == id) is Company company)
        {
            _mapper.Map(company, model);
            model.LogoPath = _fileService.GetCompanyLogo(company);
        }
        return PartialView(PartialViewConst.SaveCompany, model);
    }

    [HttpPost]
    public async Task<IActionResult> SaveCompany(CreateCompanyViewModel model)
    {
        if (ModelState.IsValid)
        {
            if (await _context.Companies.FirstOrDefaultAsync(x => x.Id == model.Id) is Company company)
            {
                _mapper.Map(model, company);
                _context.Companies.Update(company);
            }
            else
            {
                company = _mapper.Map<Company>(model);
                _context.Companies.Add(company);
                _context.SaveChanges();
            }
            if (model.Logo != null)
            {
                await _fileService.UploadCompanyLogoAsync(model.Logo, company);
                _context.Companies.Update(company);
            }
            _context.SaveChanges();
        }
        return RedirectToAction("ManageCompany", "Administration");
    }

    [HttpDelete]
    public async Task<IActionResult> DeleteCompany(int id)
    {
        var response = new AjaxResponse();
        var company = await _context.Companies.FirstOrDefaultAsync(a => a.Id == id);

        if (company != null)
        {
            response.isSuccess = true;
            _context.Companies.Remove(company);
            await _context.SaveChangesAsync();
            response.Message = "Deleted!";
        }
        else
        {
            response.isSuccess = false;
            response.Message = "Not Found!";
        }

        return Ok(response);
    }
    #endregion ManageCompany

    #region ManageBusinessType

    [HttpGet]
    public IActionResult ManageBusinessType()
    {
        return View(new BusinessType());
    }

    [HttpPost]
    public IActionResult CreateBusinessType(BusinessType model)
    {
        if (ModelState.IsValid)
        {
            var result = _context.BusinessTypes.Any(x => x.Type.ToLower() == model.Type.ToLower());
            if (!result)
            {
                _context.BusinessTypes.Add(model);
                _context.SaveChanges();
                return RedirectToAction("ManageBusinessType");
            }
            ModelState.AddModelError(string.Empty, "Duplicate Business Type");
        }
        else
        {
            ModelState.AddModelError(string.Empty, "Error in saving type");
        }
        return View("ManageBusinessType", model);
    }

    [HttpPost]
    public async Task<IActionResult> GetAllBusinessType(DtParameters dtParameters)
    {
        var searchBy = dtParameters.Search?.Value;

        // if we have an empty search then just order the results by Id ascending
        var orderCriteria = "Id";
        var orderAscendingDirection = true;

        if (dtParameters.Order != null)
        {
            // in this example we just default sort on the 1st column
            orderCriteria = dtParameters.Columns[dtParameters.Order[0].Column].Data;
            orderAscendingDirection = dtParameters.Order[0].Dir.ToString().ToLower() == "asc";
        }

        var result = _context.BusinessTypes.AsQueryable();

        if (!string.IsNullOrEmpty(searchBy))
        {
            result = result.Where(r =>
                r.Type != null && r.Type.ToUpper().Contains(searchBy.ToUpper())
            //|| r.FirstSurname != null && r.FirstSurname.ToUpper().Contains(searchBy.ToUpper())
            //|| r.SecondSurname != null && r.SecondSurname.ToUpper().Contains(searchBy.ToUpper())
            //|| r.Street != null && r.Street.ToUpper().Contains(searchBy.ToUpper()) 
            );
        }

        result = orderAscendingDirection ? result.OrderByDynamic(orderCriteria, DtOrderDir.Asc) : result.OrderByDynamic(orderCriteria, DtOrderDir.Desc);

        // now just get the count of items (without the skip and take) - eg how many could be returned with filtering
        var filteredResultsCount = await result.CountAsync();
        var totalResultsCount = await _context.BusinessTypes.CountAsync();

        return Json(new DtResult<BusinessType>
        {
            Draw = dtParameters.Draw,
            RecordsTotal = totalResultsCount,
            RecordsFiltered = filteredResultsCount,
            Data = await result
                .Skip(dtParameters.Start)
                .Take(dtParameters.Length)
                .ToListAsync()
        });
    }

    #endregion  ManageBusinessType
}