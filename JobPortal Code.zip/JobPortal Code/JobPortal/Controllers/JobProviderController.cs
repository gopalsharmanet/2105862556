﻿using AutoMapper;
using JobPortal.Data;
using JobPortal.Infrastructure;
using JobPortal.Models;
using JobPortal.Services.IServices;
using JobPortal.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Security.Claims;

namespace JobPortal.Controllers
{

    [Authorize(Roles = AppConst.Role_JobProvider)]
    public class JobProviderController : Controller
    {
        private readonly AppDbCotext _context;
        private readonly IOptionService _optionService;
        private readonly IFileService _fileService;
        private readonly IMapper _mapper;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly UserManager<ApplicationUser> _userManager;

        public JobProviderController(AppDbCotext context, IOptionService optionService, IFileService fileService, IMapper mapper, RoleManager<IdentityRole> roleManager, UserManager<ApplicationUser> userManager)
        {
            _context = context;
            _optionService = optionService;
            _fileService = fileService;
            _mapper = mapper;
            _roleManager = roleManager;
            _userManager = userManager;
        }

        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Profile()
        {
            return View();
        }

        public IActionResult Applications()
        {
            return View();
        }
        public async Task<IActionResult> GetAllApplication(DtParameters dtParameters)
        {
            var searchBy = dtParameters.Search?.Value;

            // if we have an empty search then just order the results by Id ascending
            var orderCriteria = "Id";
            var orderAscendingDirection = true;

            if (dtParameters.Order != null)
            {
                // in this example we just default sort on the 1st column
                orderCriteria = dtParameters.Columns[dtParameters.Order[0].Column].Data;
                orderAscendingDirection = dtParameters.Order[0].Dir.ToString().ToLower() == "asc";
            }
            var user = User.FindFirst(ClaimTypes.NameIdentifier)?.Value ?? "";
            var result = _context.JobApplications
                .Include(i => i.Job)
                    .ThenInclude(ti => ti.JobRole)
                .Include(i => i.ApplicationUser).Where(x => x.Job.JobProviderId == user)
                .AsQueryable();

            if (!string.IsNullOrEmpty(searchBy))
            {
                //result = result.Where(r =>
                //    //r.ApplyDate != null && r.job.SkillName.ToUpper().Contains(searchBy.ToUpper())
                // r.ApplicationUser.FirstName != null && r.ApplicationUser.FirstName.ToUpper().Contains(searchBy.ToUpper())
                //|| r.ApplicationUser.LastName != null && r.ApplicationUser.LastName.ToUpper().Contains(searchBy.ToUpper())
                //|| r.Job.JobRole.JobTitle != null && r.Job.JobRole.JobTitle.ToUpper().Contains(searchBy.ToUpper())
                //|| r.AppStatus.ToString() != null && r.AppStatus.ToString().ToUpper().Contains(searchBy.ToUpper())
                //);
            }

            result = orderAscendingDirection ? result.OrderByDynamic(orderCriteria, DtOrderDir.Asc) : result.OrderByDynamic(orderCriteria, DtOrderDir.Desc);

            // now just get the count of items (without the skip and take) - eg how many could be returned with filtering
            var filteredResultsCount = await result.CountAsync();
            var totalResultsCount = await result.CountAsync();

            var applications = await result.Skip(dtParameters.Start).Take(dtParameters.Length).ToListAsync();

            applications.ForEach(ja =>
            {
                ja.ApplicationUser.PhotoPath = _fileService.GetUserProfile(ja.ApplicationUser);
                ja.ApplicationUser.ResumePath = _fileService.GetUserCV(ja.ApplicationUser);
            });

            var data = _mapper.Map<List<JobApplicationDT>>(applications);


            return Json(new DtResult<JobApplicationDT>
            {
                Draw = dtParameters.Draw,
                RecordsTotal = totalResultsCount,
                RecordsFiltered = filteredResultsCount,
                Data = data
            });
        }


        public async Task<IActionResult> JobSeekerProfile(string jobSeekerId)
        {
            var user = await _context.Users
                .Include(a => a.JobRole)
                .Include(a => a.City)
                .Include(a => a.Company)
                .Include(a => a.UserCV)
                    .ThenInclude(a => a.Skills)
                .FirstAsync(a => a.Id == jobSeekerId);
            List<JobSeekerEducation> educations = new List<JobSeekerEducation>();
            List<JobSeekerExperienceDetails> experienceDetails = new List<JobSeekerExperienceDetails>();

            if (user.UserCV != null)
            {
                educations = await _context.JobSeekerEducations.Where(a => a.CVId == user.UserCV.Id).OrderByDescending(a => a.EduLevel).ToListAsync();
                experienceDetails = await _context.ExperienceDetails.Where(a => a.CVId == user.UserCV.Id).OrderByDescending(a => a.IsCurrentJob).ToListAsync();
            }

            var model = new ProfileViewModel
            {
                MyCVFileSrc = _fileService.GetUserCV(user),
                MyProfileImageSrc = _fileService.GetUserProfile(user),
                Skills = user.UserCV?.Skills.Select(a => a.SkillName) ?? new List<string>(),
                City = user.City.CityName,
                Job = user.JobRole.JobTitle,
                Company = user.Company?.CompanyName,
                Experiences = _mapper.Map<List<ExperienceViewModel>>(experienceDetails),
                Educations = _mapper.Map<List<EducationViewModel>>(educations)
            };

            _mapper.Map(user, model);

            return View(model);
        }

        [HttpPost]
        public IActionResult JobSeekerAction(int appId, ApplicationStatus status)
        {
            var response = new AjaxResponse();
            var jobApplication = _context.JobApplications.FirstOrDefault(i => i.Id == appId);

            if (jobApplication != null)
            {
                jobApplication.AppStatus = status;
                response.isSuccess = true;
                response.Message = "Application updated successfully.";
                _context.JobApplications.Update(jobApplication);
                _context.SaveChanges();
            }
            else
            {
                response.isSuccess = false;
                response.Message = "Application not found.";
            }

            return Ok(response);
        }
    }
}
