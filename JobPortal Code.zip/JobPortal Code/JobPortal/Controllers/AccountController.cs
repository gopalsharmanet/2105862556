﻿using JobPortal.Models;
using JobPortal.ViewModels;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Infrastructure;
using Microsoft.Extensions.Hosting.Internal;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc.Rendering;
using JobPortal.Services.IServices;
using Microsoft.AspNetCore.Authorization;
using JobPortal.Infrastructure;
using System.Security.Claims;
using Microsoft.EntityFrameworkCore;

namespace JobPortal.Controllers
{
    public class AccountController : Controller
    {
        private readonly UserManager<ApplicationUser> userManager;
        private readonly SignInManager<ApplicationUser> signInManager;
        private readonly IWebHostEnvironment hostingEnvironment;
        private readonly AppDbCotext context;
        private readonly IOptionService optionManager;

        public AccountController(UserManager<ApplicationUser> userManager,
                                SignInManager<ApplicationUser> signInManager,
                                IWebHostEnvironment hostingEnvironment,
                                AppDbCotext context,
                                IOptionService optionManager)
        {
            this.userManager = userManager;
            this.signInManager = signInManager;
            this.hostingEnvironment = hostingEnvironment;
            this.context = context;
            this.optionManager = optionManager;
        }

        [HttpGet]
        public async Task<IActionResult> Login(string returnUrl)
        {
            LoginViewModel model = new()
            {
                ReturnUrl = returnUrl,
                ExternalLogins = (await (signInManager.GetExternalAuthenticationSchemesAsync())).ToList()
            };
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Login(LoginViewModel model, string returnUrl)
        {
            model.ExternalLogins = (await signInManager.GetExternalAuthenticationSchemesAsync()).ToList();
            if (ModelState.IsValid)
            {
                var user = await userManager.FindByEmailAsync(model.Email);

                //if (user != null && !user.EmailConfirmed && (await userManager.CheckPasswordAsync(user, model.Password)))
                //{
                //    ModelState.AddModelError(string.Empty, "Email not Confirmed");
                //    return View(model);
                //}
                if (user != null)
                {
                    var result = await signInManager.PasswordSignInAsync(user, model.Password, model.RememberMe, false);
                    if (result.Succeeded)
                    {
                        if (!string.IsNullOrEmpty(returnUrl) && Url.IsLocalUrl(returnUrl))
                        {
                            return Redirect(returnUrl);
                        }
                        else
                        {
                            return RedirectToAction("Dashboard", "home");
                        }
                    }
                    else
                    {
                        if (result.IsLockedOut)
                        {
                            ModelState.AddModelError(string.Empty, "Account is locked");
                        }
                        else
                        {
                            ModelState.AddModelError(string.Empty, "Email or Password doesn't match");
                        }
                    }

                }

                ModelState.AddModelError(string.Empty, "Failed login attempt");
            }
            return View(model);
        }

        [HttpGet]
        public IActionResult Register()
        {
            var model = new RegisterViewModel();
            model.CurrentCityItems = optionManager.GetAllCities();
            return View(model);
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                var user = new ApplicationUser
                {
                    UserName = model.Name,
                    Email = model.Email,
                    CurrentCityId = model.CurrentCityId,
                    PhoneNumber = model.PhoneNumber

                };
                var result = await userManager.CreateAsync(user, model.Password);
                if (result.Succeeded)
                {
                    if (model.Photo != null)
                    {
                        user.PhotoPath = ProcessUploadedPhoto(model);
                    }
                    IdentityRole Role = new()
                    {
                        Name = (model.SelectedRole).ToString()
                    };

                    IdentityResult Result = await userManager.AddToRoleAsync(user, Role.Name);

                    if (Result.Succeeded)
                    {
                        await signInManager.SignInAsync(user, true);
                        return RedirectToAction("Index", "Home");
                    }

                    ModelState.AddModelError(string.Empty, "Some error in assigning role. Contact Admin");

                }
                foreach (var error in result.Errors)
                {
                    ModelState.AddModelError(string.Empty, error.Description);
                }
            }
            return View(model);

        }

        public string ProcessUploadedPhoto(RegisterViewModel model)
        {
            string UniqueFileName = Guid.NewGuid() + "_" + model.Photo.FileName;

            string UploadsFolder = Path.Combine(hostingEnvironment.WebRootPath, "Images");
            string FilePath = Path.Combine(UploadsFolder, UniqueFileName);
            using (var FileStream = new FileStream(FilePath, FileMode.Create))
            {
                model.Photo.CopyTo(FileStream);
            }
            return FilePath;
        }

        [Authorize]
        public async Task<IActionResult> Logout()
        {
            await signInManager.SignOutAsync();
            return RedirectToAction("index", "home");
        }

        [Authorize]
        [HttpPost]
        public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            var user = await userManager.GetUserAsync(User);

            var result = await userManager.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword);
            if (!result.Succeeded)
            {

            }
            if (User.IsInRole(AppConst.Role_JobSeeker))
            {
                return RedirectToAction(controllerName: "JobSeeker", actionName: "Profile");
            }
            else if (User.IsInRole(AppConst.Role_JobProvider))
            {
                return RedirectToAction(controllerName: "JobProvider", actionName: "Profile");
            }
            else if (User.IsInRole(AppConst.Role_Admin))
            {
                return RedirectToAction(controllerName: "Administration", actionName: "Profile");
            }
            else
            {
                return View();
            }
        }

        [Authorize]
        public async Task<IActionResult> Profile()
        {
            var user = await userManager.GetUserAsync(User);

            if (User.IsInRole(AppConst.Role_JobSeeker))
            {
                return RedirectToAction(controllerName: "JobSeeker", actionName: "Profile");
            }
            else if (User.IsInRole(AppConst.Role_JobProvider))
            {
                return RedirectToAction(controllerName: "JobProvider", actionName: "Profile");
            }
            else if (User.IsInRole(AppConst.Role_Admin))
            {
                return RedirectToAction(controllerName: "Administration", actionName: "Profile");
            }
            else
            {
                return Unauthorized();
            }
        }

        public IActionResult AccessDenied(string returnUrl)
        {
            return View();
        }

    }
}
