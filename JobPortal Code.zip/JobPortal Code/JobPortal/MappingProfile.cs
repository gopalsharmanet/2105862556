﻿using AutoMapper;
using JobPortal.Models;
using JobPortal.Models.ViewModels;
using JobPortal.ViewModels;

namespace JobPortal
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<CityAddEditModel, City>().ReverseMap();

            CreateMap<EducationViewModel, JobSeekerEducation>().ReverseMap();
            CreateMap<ExperienceViewModel, JobSeekerExperienceDetails>().ReverseMap();

            CreateMap<Company, CompanyDT>()
            .ForMember(dest => dest.BusinessType, opt => opt.MapFrom(src => src.BusinessType.Type))
            .ForMember(dest => dest.City, opt => opt.MapFrom(src => src.City.CityName))
            .ReverseMap();

            CreateMap<ProfileViewModel, ApplicationUser>()
            .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.FirstName))
            .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LastName))
            .ForMember(dest => dest.CompanyId, opt => opt.MapFrom(src => src.CurrentCompanyId))
            .ForMember(dest => dest.JobRoleId, opt => opt.MapFrom(src => src.CurrentJobId))
            .ForMember(dest => dest.CurrentCityId, opt => opt.MapFrom(src => src.CurrentCityId))
            .ForMember(dest => dest.Address, opt => opt.MapFrom(src => src.Address))
            .ForMember(dest => dest.PhoneNumber, opt => opt.MapFrom(src => src.Phone))
            .ForMember(dest => dest.Languages, opt => opt.MapFrom(src => src.CurrentLanguage))
            .ForMember(dest => dest.Email, opt => opt.MapFrom(src => src.Email))
            .ForMember(dest => dest.Instagram, opt => opt.MapFrom(src => src.Instagram))
            .ForMember(dest => dest.LinkedIn, opt => opt.MapFrom(src => src.Linkedin))
            .ForMember(dest => dest.Facebook, opt => opt.MapFrom(src => src.Facebook))
            .ForMember(dest => dest.Twitter, opt => opt.MapFrom(src => src.Twitter));

            CreateMap<ApplicationUser, ProfileViewModel>()
            .ForMember(dest => dest.AboutMe, opt => opt.MapFrom(src => src.UserCV != null ? src.UserCV.AboutMe : null))
            .ForMember(dest => dest.FullName, opt => opt.MapFrom(src => src.FullName))
            .ForMember(dest => dest.Phone, opt => opt.MapFrom(src => src.PhoneNumber))
            .ForMember(dest => dest.FirstName, opt => opt.MapFrom(src => src.FirstName))
            .ForMember(dest => dest.LastName, opt => opt.MapFrom(src => src.LastName))
            .ForMember(dest => dest.CurrentJobId, opt => opt.MapFrom(src => src.JobRoleId))
            .ForMember(dest => dest.CurrentLanguage, opt => opt.MapFrom(src => src.Languages))
            .ForMember(dest => dest.Instagram, opt => opt.MapFrom(src => src.Instagram))
            .ForMember(dest => dest.Facebook, opt => opt.MapFrom(src => src.Facebook))
            .ForMember(dest => dest.Email, opt => opt.MapFrom(src => src.Email))
            .ForMember(dest => dest.Linkedin, opt => opt.MapFrom(src => src.LinkedIn))
            .ForMember(dest => dest.Address, opt => opt.MapFrom(src => src.Address))
            .ForMember(dest => dest.City, opt => opt.MapFrom(src => src.City.CityName))
            .ForMember(dest => dest.Twitter, opt => opt.MapFrom(src => src.Twitter));

            CreateMap<CreateCompanyViewModel, Company>()
                .ForMember(dest => dest.CompanyLogoPath, opt => opt.Ignore())
                .ReverseMap();

            CreateMap<Job, JobSummary>()
                .ForMember(dest => dest.JobRole, opt => opt.MapFrom(src => src.JobRole.JobTitle))
                .ForMember(dest => dest.Company, opt => opt.MapFrom(src => src.Company.CompanyName))
                .ForMember(dest => dest.JobSkills, opt => opt.MapFrom(src => src.Skills.Select(s => s.SkillName).OrderBy(s => s)))
                //.ForMember(dest => dest.City, opt => opt.MapFrom(src => src.City))
                .ReverseMap();

            CreateMap<JobApplication, JobApplicationDT>()
                .ForMember(dest => dest.JobTitle, opt => opt.MapFrom(src => src.Job.JobRole.JobTitle))
                .ForMember(dest => dest.JobSeekerName, opt => opt.MapFrom(src => src.ApplicationUser.FullName))
                .ForMember(dest => dest.PhotoUrl, opt => opt.MapFrom(src => src.ApplicationUser.PhotoPath))
                .ForMember(dest => dest.CvUrl, opt => opt.MapFrom(src => src.ApplicationUser.ResumePath))
                .ForMember(dest => dest.JobSeekerId, opt => opt.MapFrom(src => src.ApplicationUser.Id))
                .ForMember(dest => dest.Status, opt => opt.MapFrom(src => src.AppStatus))
                .ForMember(dest => dest.StatusInt, opt => opt.MapFrom(src => src.AppStatus));

            CreateMap<JobViewModel, Job>().ReverseMap();
        }
    }
}
