using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace JobPortal.Views.Administration
{
    public class NotFoundModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
