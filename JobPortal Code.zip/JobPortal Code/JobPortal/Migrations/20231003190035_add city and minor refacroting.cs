﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JobPortal.Migrations
{
    public partial class Addcityandminorrefacroting : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_jobSeekerSkillSets_AspNetUsers_JobSeekerId",
                table: "jobSeekerSkillSets");

            migrationBuilder.DropForeignKey(
                name: "FK_jobSeekerSkillSets_Skills_SkillId",
                table: "jobSeekerSkillSets");

            migrationBuilder.DropTable(
                name: "BookmarkedJobs");

            migrationBuilder.DropPrimaryKey(
                name: "PK_jobSeekerSkillSets",
                table: "jobSeekerSkillSets");

            migrationBuilder.DropColumn(
                name: "IsAccepted",
                table: "JobApplications");

            migrationBuilder.DropColumn(
                name: "IsHired",
                table: "JobApplications");

            migrationBuilder.DropColumn(
                name: "IsRejected",
                table: "JobApplications");

            migrationBuilder.RenameTable(
                name: "jobSeekerSkillSets",
                newName: "JobSeekerSkillSets");

            migrationBuilder.RenameIndex(
                name: "IX_jobSeekerSkillSets_SkillId",
                table: "JobSeekerSkillSets",
                newName: "IX_JobSeekerSkillSets_SkillId");

            migrationBuilder.RenameIndex(
                name: "IX_jobSeekerSkillSets_JobSeekerId",
                table: "JobSeekerSkillSets",
                newName: "IX_JobSeekerSkillSets_JobSeekerId");

            migrationBuilder.RenameColumn(
                name: "CurrentCity",
                table: "AspNetUsers",
                newName: "WebsiteUrl");

            migrationBuilder.AddColumn<int>(
                name: "CompanyId",
                table: "Jobs",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<bool>(
                name: "IsPermanent",
                table: "Jobs",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<int>(
                name: "AppStatus",
                table: "JobApplications",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<DateTime>(
                name: "CreateDate",
                table: "AspNetUsers",
                type: "datetime2",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified));

            migrationBuilder.AddColumn<int>(
                name: "CurrentCityId",
                table: "AspNetUsers",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_JobSeekerSkillSets",
                table: "JobSeekerSkillSets",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "City",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CityName = table.Column<string>(type: "nvarchar(50)", maxLength: 50, nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_City", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SavedJobs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SaveDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    JobSeekerId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SavedJobs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SavedJobs_AspNetUsers_JobSeekerId",
                        column: x => x.JobSeekerId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_Jobs_CompanyId",
                table: "Jobs",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_CurrentCityId",
                table: "AspNetUsers",
                column: "CurrentCityId");

            migrationBuilder.CreateIndex(
                name: "IX_SavedJobs_JobSeekerId",
                table: "SavedJobs",
                column: "JobSeekerId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_City_CurrentCityId",
                table: "AspNetUsers",
                column: "CurrentCityId",
                principalTable: "City",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Jobs_Companies_CompanyId",
                table: "Jobs",
                column: "CompanyId",
                principalTable: "Companies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_JobSeekerSkillSets_AspNetUsers_JobSeekerId",
                table: "JobSeekerSkillSets",
                column: "JobSeekerId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobSeekerSkillSets_Skills_SkillId",
                table: "JobSeekerSkillSets",
                column: "SkillId",
                principalTable: "Skills",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_City_CurrentCityId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_Jobs_Companies_CompanyId",
                table: "Jobs");

            migrationBuilder.DropForeignKey(
                name: "FK_JobSeekerSkillSets_AspNetUsers_JobSeekerId",
                table: "JobSeekerSkillSets");

            migrationBuilder.DropForeignKey(
                name: "FK_JobSeekerSkillSets_Skills_SkillId",
                table: "JobSeekerSkillSets");

            migrationBuilder.DropTable(
                name: "City");

            migrationBuilder.DropTable(
                name: "SavedJobs");

            migrationBuilder.DropPrimaryKey(
                name: "PK_JobSeekerSkillSets",
                table: "JobSeekerSkillSets");

            migrationBuilder.DropIndex(
                name: "IX_Jobs_CompanyId",
                table: "Jobs");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_CurrentCityId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "CompanyId",
                table: "Jobs");

            migrationBuilder.DropColumn(
                name: "IsPermanent",
                table: "Jobs");

            migrationBuilder.DropColumn(
                name: "AppStatus",
                table: "JobApplications");

            migrationBuilder.DropColumn(
                name: "CreateDate",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "CurrentCityId",
                table: "AspNetUsers");

            migrationBuilder.RenameTable(
                name: "JobSeekerSkillSets",
                newName: "jobSeekerSkillSets");

            migrationBuilder.RenameIndex(
                name: "IX_JobSeekerSkillSets_SkillId",
                table: "jobSeekerSkillSets",
                newName: "IX_jobSeekerSkillSets_SkillId");

            migrationBuilder.RenameIndex(
                name: "IX_JobSeekerSkillSets_JobSeekerId",
                table: "jobSeekerSkillSets",
                newName: "IX_jobSeekerSkillSets_JobSeekerId");

            migrationBuilder.RenameColumn(
                name: "WebsiteUrl",
                table: "AspNetUsers",
                newName: "CurrentCity");

            migrationBuilder.AddColumn<bool>(
                name: "IsAccepted",
                table: "JobApplications",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsHired",
                table: "JobApplications",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsRejected",
                table: "JobApplications",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddPrimaryKey(
                name: "PK_jobSeekerSkillSets",
                table: "jobSeekerSkillSets",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "BookmarkedJobs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JobSeekerId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    BookmarkDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BookmarkedJobs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BookmarkedJobs_AspNetUsers_JobSeekerId",
                        column: x => x.JobSeekerId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_BookmarkedJobs_JobSeekerId",
                table: "BookmarkedJobs",
                column: "JobSeekerId");

            migrationBuilder.AddForeignKey(
                name: "FK_jobSeekerSkillSets_AspNetUsers_JobSeekerId",
                table: "jobSeekerSkillSets",
                column: "JobSeekerId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_jobSeekerSkillSets_Skills_SkillId",
                table: "jobSeekerSkillSets",
                column: "SkillId",
                principalTable: "Skills",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
