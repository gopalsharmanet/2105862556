﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JobPortal.Migrations
{
    public partial class UpdateBookmarkedJob_Added_JobId : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "JobId",
                table: "BookmarkedJobs",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_BookmarkedJobs_JobId",
                table: "BookmarkedJobs",
                column: "JobId");

            migrationBuilder.AddForeignKey(
                name: "FK_BookmarkedJobs_Jobs_JobId",
                table: "BookmarkedJobs",
                column: "JobId",
                principalTable: "Jobs",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_BookmarkedJobs_Jobs_JobId",
                table: "BookmarkedJobs");

            migrationBuilder.DropIndex(
                name: "IX_BookmarkedJobs_JobId",
                table: "BookmarkedJobs");

            migrationBuilder.DropColumn(
                name: "JobId",
                table: "BookmarkedJobs");
        }
    }
}
