﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JobPortal.Migrations
{
    public partial class Refactor_classes_from_earlier_migration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "ApplicationStatus",
                table: "JobApplications");

            migrationBuilder.AddColumn<bool>(
                name: "IsAccepted",
                table: "JobApplications",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsHired",
                table: "JobApplications",
                type: "bit",
                nullable: false,
                defaultValue: false);

            migrationBuilder.AddColumn<bool>(
                name: "IsRejected",
                table: "JobApplications",
                type: "bit",
                nullable: false,
                defaultValue: false);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsAccepted",
                table: "JobApplications");

            migrationBuilder.DropColumn(
                name: "IsHired",
                table: "JobApplications");

            migrationBuilder.DropColumn(
                name: "IsRejected",
                table: "JobApplications");

            migrationBuilder.AddColumn<int>(
                name: "ApplicationStatus",
                table: "JobApplications",
                type: "int",
                nullable: false,
                defaultValue: 0);
        }
    }
}
