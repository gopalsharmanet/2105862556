﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JobPortal.Migrations
{
    public partial class AddJobRole : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "JobRoleId",
                table: "Jobs",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "JobRoleId",
                table: "AspNetUsers",
                type: "int",
                nullable: true);

            migrationBuilder.CreateTable(
                name: "JobRoles",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JobTitle = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_JobRoles", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_Jobs_JobRoleId",
                table: "Jobs",
                column: "JobRoleId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_JobRoleId",
                table: "AspNetUsers",
                column: "JobRoleId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_JobRoles_JobRoleId",
                table: "AspNetUsers",
                column: "JobRoleId",
                principalTable: "JobRoles",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Jobs_JobRoles_JobRoleId",
                table: "Jobs",
                column: "JobRoleId",
                principalTable: "JobRoles",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_JobRoles_JobRoleId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_Jobs_JobRoles_JobRoleId",
                table: "Jobs");

            migrationBuilder.DropTable(
                name: "JobRoles");

            migrationBuilder.DropIndex(
                name: "IX_Jobs_JobRoleId",
                table: "Jobs");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_JobRoleId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "JobRoleId",
                table: "Jobs");

            migrationBuilder.DropColumn(
                name: "JobRoleId",
                table: "AspNetUsers");
        }
    }
}
