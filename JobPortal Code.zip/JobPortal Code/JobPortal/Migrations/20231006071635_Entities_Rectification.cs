﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace JobPortal.Migrations
{
    public partial class Entities_Rectification : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Companies_BusinessType_BusinessTypeId",
                table: "Companies");

            migrationBuilder.DropForeignKey(
                name: "FK_ExperienceDetails_AspNetUsers_JobSeekerId",
                table: "ExperienceDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_Feedbacks_AspNetUsers_JobSeekerID",
                table: "Feedbacks");

            migrationBuilder.DropForeignKey(
                name: "FK_JobApplications_AspNetUsers_JobSeekerId",
                table: "JobApplications");

            migrationBuilder.DropForeignKey(
                name: "FK_Jobs_AspNetUsers_JobProviderId",
                table: "Jobs");

            migrationBuilder.DropForeignKey(
                name: "FK_JobSeekerEducations_AspNetUsers_JobSeekerId",
                table: "JobSeekerEducations");

            migrationBuilder.DropForeignKey(
                name: "FK_JobSeekerSkillSets_AspNetUsers_JobSeekerId",
                table: "JobSeekerSkillSets");

            migrationBuilder.DropTable(
                name: "SavedJobs");

            migrationBuilder.DropIndex(
                name: "IX_JobSeekerSkillSets_JobSeekerId",
                table: "JobSeekerSkillSets");

            migrationBuilder.DropIndex(
                name: "IX_JobSeekerEducations_JobSeekerId",
                table: "JobSeekerEducations");

            migrationBuilder.DropIndex(
                name: "IX_Jobs_JobProviderId",
                table: "Jobs");

            migrationBuilder.DropIndex(
                name: "IX_JobApplications_JobSeekerId",
                table: "JobApplications");

            migrationBuilder.DropIndex(
                name: "IX_ExperienceDetails_JobSeekerId",
                table: "ExperienceDetails");

            migrationBuilder.DropPrimaryKey(
                name: "PK_BusinessType",
                table: "BusinessType");

            migrationBuilder.DropColumn(
                name: "JobSeekerId",
                table: "JobSeekerSkillSets");

            migrationBuilder.DropColumn(
                name: "JobSeekerId",
                table: "JobSeekerEducations");

            migrationBuilder.DropColumn(
                name: "JobSeekerId",
                table: "ExperienceDetails");

            migrationBuilder.DropColumn(
                name: "Discriminator",
                table: "AspNetUsers");

            migrationBuilder.RenameTable(
                name: "BusinessType",
                newName: "BusinessTypes");

            migrationBuilder.RenameColumn(
                name: "JobSeekerID",
                table: "Feedbacks",
                newName: "ApplicationUserId");

            migrationBuilder.RenameIndex(
                name: "IX_Feedbacks_JobSeekerID",
                table: "Feedbacks",
                newName: "IX_Feedbacks_ApplicationUserId");

            migrationBuilder.AddColumn<int>(
                name: "CVId",
                table: "JobSeekerSkillSets",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CVId",
                table: "JobSeekerEducations",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<string>(
                name: "JobProviderId",
                table: "Jobs",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ApplicationUserId",
                table: "Jobs",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "JobSeekerId",
                table: "JobApplications",
                type: "nvarchar(max)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "ApplicationUserId",
                table: "JobApplications",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "AppUserId",
                table: "Feedbacks",
                type: "nvarchar(max)",
                nullable: true);

            migrationBuilder.AddColumn<int>(
                name: "CVId",
                table: "ExperienceDetails",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CVId",
                table: "AspNetUsers",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<int>(
                name: "CompanyId",
                table: "AspNetUsers",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddPrimaryKey(
                name: "PK_BusinessTypes",
                table: "BusinessTypes",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "BookmarkedJobs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SaveDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    AppUserId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ApplicationUserId = table.Column<string>(type: "nvarchar(450)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BookmarkedJobs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_BookmarkedJobs_AspNetUsers_ApplicationUserId",
                        column: x => x.ApplicationUserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateTable(
                name: "CVs",
                columns: table => new
                {
                    CVId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    AboutMe = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    AppUserId = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CVs", x => x.CVId);
                });

            migrationBuilder.CreateTable(
                name: "messages",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Text = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SenderId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ReceiverId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SendDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_messages", x => x.Id);
                });

            migrationBuilder.CreateIndex(
                name: "IX_JobSeekerSkillSets_CVId",
                table: "JobSeekerSkillSets",
                column: "CVId");

            migrationBuilder.CreateIndex(
                name: "IX_JobSeekerEducations_CVId",
                table: "JobSeekerEducations",
                column: "CVId");

            migrationBuilder.CreateIndex(
                name: "IX_Jobs_ApplicationUserId",
                table: "Jobs",
                column: "ApplicationUserId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplications_ApplicationUserId",
                table: "JobApplications",
                column: "ApplicationUserId");

            migrationBuilder.CreateIndex(
                name: "IX_ExperienceDetails_CVId",
                table: "ExperienceDetails",
                column: "CVId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_CompanyId",
                table: "AspNetUsers",
                column: "CompanyId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUsers_CVId",
                table: "AspNetUsers",
                column: "CVId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_BookmarkedJobs_ApplicationUserId",
                table: "BookmarkedJobs",
                column: "ApplicationUserId");

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_Companies_CompanyId",
                table: "AspNetUsers",
                column: "CompanyId",
                principalTable: "Companies",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_AspNetUsers_CVs_CVId",
                table: "AspNetUsers",
                column: "CVId",
                principalTable: "CVs",
                principalColumn: "CVId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Companies_BusinessTypes_BusinessTypeId",
                table: "Companies",
                column: "BusinessTypeId",
                principalTable: "BusinessTypes",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExperienceDetails_CVs_CVId",
                table: "ExperienceDetails",
                column: "CVId",
                principalTable: "CVs",
                principalColumn: "CVId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_Feedbacks_AspNetUsers_ApplicationUserId",
                table: "Feedbacks",
                column: "ApplicationUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobApplications_AspNetUsers_ApplicationUserId",
                table: "JobApplications",
                column: "ApplicationUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Jobs_AspNetUsers_ApplicationUserId",
                table: "Jobs",
                column: "ApplicationUserId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobSeekerEducations_CVs_CVId",
                table: "JobSeekerEducations",
                column: "CVId",
                principalTable: "CVs",
                principalColumn: "CVId",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_JobSeekerSkillSets_CVs_CVId",
                table: "JobSeekerSkillSets",
                column: "CVId",
                principalTable: "CVs",
                principalColumn: "CVId",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_Companies_CompanyId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_AspNetUsers_CVs_CVId",
                table: "AspNetUsers");

            migrationBuilder.DropForeignKey(
                name: "FK_Companies_BusinessTypes_BusinessTypeId",
                table: "Companies");

            migrationBuilder.DropForeignKey(
                name: "FK_ExperienceDetails_CVs_CVId",
                table: "ExperienceDetails");

            migrationBuilder.DropForeignKey(
                name: "FK_Feedbacks_AspNetUsers_ApplicationUserId",
                table: "Feedbacks");

            migrationBuilder.DropForeignKey(
                name: "FK_JobApplications_AspNetUsers_ApplicationUserId",
                table: "JobApplications");

            migrationBuilder.DropForeignKey(
                name: "FK_Jobs_AspNetUsers_ApplicationUserId",
                table: "Jobs");

            migrationBuilder.DropForeignKey(
                name: "FK_JobSeekerEducations_CVs_CVId",
                table: "JobSeekerEducations");

            migrationBuilder.DropForeignKey(
                name: "FK_JobSeekerSkillSets_CVs_CVId",
                table: "JobSeekerSkillSets");

            migrationBuilder.DropTable(
                name: "BookmarkedJobs");

            migrationBuilder.DropTable(
                name: "CVs");

            migrationBuilder.DropTable(
                name: "messages");

            migrationBuilder.DropIndex(
                name: "IX_JobSeekerSkillSets_CVId",
                table: "JobSeekerSkillSets");

            migrationBuilder.DropIndex(
                name: "IX_JobSeekerEducations_CVId",
                table: "JobSeekerEducations");

            migrationBuilder.DropIndex(
                name: "IX_Jobs_ApplicationUserId",
                table: "Jobs");

            migrationBuilder.DropIndex(
                name: "IX_JobApplications_ApplicationUserId",
                table: "JobApplications");

            migrationBuilder.DropIndex(
                name: "IX_ExperienceDetails_CVId",
                table: "ExperienceDetails");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_CompanyId",
                table: "AspNetUsers");

            migrationBuilder.DropIndex(
                name: "IX_AspNetUsers_CVId",
                table: "AspNetUsers");

            migrationBuilder.DropPrimaryKey(
                name: "PK_BusinessTypes",
                table: "BusinessTypes");

            migrationBuilder.DropColumn(
                name: "CVId",
                table: "JobSeekerSkillSets");

            migrationBuilder.DropColumn(
                name: "CVId",
                table: "JobSeekerEducations");

            migrationBuilder.DropColumn(
                name: "ApplicationUserId",
                table: "Jobs");

            migrationBuilder.DropColumn(
                name: "ApplicationUserId",
                table: "JobApplications");

            migrationBuilder.DropColumn(
                name: "AppUserId",
                table: "Feedbacks");

            migrationBuilder.DropColumn(
                name: "CVId",
                table: "ExperienceDetails");

            migrationBuilder.DropColumn(
                name: "CVId",
                table: "AspNetUsers");

            migrationBuilder.DropColumn(
                name: "CompanyId",
                table: "AspNetUsers");

            migrationBuilder.RenameTable(
                name: "BusinessTypes",
                newName: "BusinessType");

            migrationBuilder.RenameColumn(
                name: "ApplicationUserId",
                table: "Feedbacks",
                newName: "JobSeekerID");

            migrationBuilder.RenameIndex(
                name: "IX_Feedbacks_ApplicationUserId",
                table: "Feedbacks",
                newName: "IX_Feedbacks_JobSeekerID");

            migrationBuilder.AddColumn<string>(
                name: "JobSeekerId",
                table: "JobSeekerSkillSets",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "JobSeekerId",
                table: "JobSeekerEducations",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "JobProviderId",
                table: "Jobs",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AlterColumn<string>(
                name: "JobSeekerId",
                table: "JobApplications",
                type: "nvarchar(450)",
                nullable: true,
                oldClrType: typeof(string),
                oldType: "nvarchar(max)",
                oldNullable: true);

            migrationBuilder.AddColumn<string>(
                name: "JobSeekerId",
                table: "ExperienceDetails",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.AddColumn<string>(
                name: "Discriminator",
                table: "AspNetUsers",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddPrimaryKey(
                name: "PK_BusinessType",
                table: "BusinessType",
                column: "Id");

            migrationBuilder.CreateTable(
                name: "SavedJobs",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    JobSeekerId = table.Column<string>(type: "nvarchar(450)", nullable: true),
                    SaveDate = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SavedJobs", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SavedJobs_AspNetUsers_JobSeekerId",
                        column: x => x.JobSeekerId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id");
                });

            migrationBuilder.CreateIndex(
                name: "IX_JobSeekerSkillSets_JobSeekerId",
                table: "JobSeekerSkillSets",
                column: "JobSeekerId");

            migrationBuilder.CreateIndex(
                name: "IX_JobSeekerEducations_JobSeekerId",
                table: "JobSeekerEducations",
                column: "JobSeekerId");

            migrationBuilder.CreateIndex(
                name: "IX_Jobs_JobProviderId",
                table: "Jobs",
                column: "JobProviderId");

            migrationBuilder.CreateIndex(
                name: "IX_JobApplications_JobSeekerId",
                table: "JobApplications",
                column: "JobSeekerId");

            migrationBuilder.CreateIndex(
                name: "IX_ExperienceDetails_JobSeekerId",
                table: "ExperienceDetails",
                column: "JobSeekerId");

            migrationBuilder.CreateIndex(
                name: "IX_SavedJobs_JobSeekerId",
                table: "SavedJobs",
                column: "JobSeekerId");

            migrationBuilder.AddForeignKey(
                name: "FK_Companies_BusinessType_BusinessTypeId",
                table: "Companies",
                column: "BusinessTypeId",
                principalTable: "BusinessType",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ExperienceDetails_AspNetUsers_JobSeekerId",
                table: "ExperienceDetails",
                column: "JobSeekerId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Feedbacks_AspNetUsers_JobSeekerID",
                table: "Feedbacks",
                column: "JobSeekerID",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobApplications_AspNetUsers_JobSeekerId",
                table: "JobApplications",
                column: "JobSeekerId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_Jobs_AspNetUsers_JobProviderId",
                table: "Jobs",
                column: "JobProviderId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobSeekerEducations_AspNetUsers_JobSeekerId",
                table: "JobSeekerEducations",
                column: "JobSeekerId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");

            migrationBuilder.AddForeignKey(
                name: "FK_JobSeekerSkillSets_AspNetUsers_JobSeekerId",
                table: "JobSeekerSkillSets",
                column: "JobSeekerId",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
