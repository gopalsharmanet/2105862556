﻿using JobPortal.Models;
using JobPortal.Services.IServices;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace JobPortal.Services
{
    public class OptionService : IOptionService
    {
        private readonly AppDbCotext _context;

        public OptionService(AppDbCotext context)
        {
            _context = context;
        }

        public IEnumerable<SelectListItem> GetAllCities()
        {
            var selectListItems = _context.Cities.OrderBy(x => x.CityName).Select(x => new SelectListItem
            {
                Text = x.CityName,
                Value = x.Id.ToString(),
            });
            return selectListItems;
        }

        public IEnumerable<SelectListItem> GetAllRoles()
        {
            var selectListItems = _context.Roles.Select(x => new SelectListItem
            {
                Value = x.Id,
                Text = x.Name,
            });
            return selectListItems;
        }

        public IEnumerable<SelectListItem> GetAllSkills()
        {
            var selectListItems = _context.Skills.OrderBy(x => x.SkillName).Select(x => new SelectListItem
            {
                Text = x.SkillName,
                Value = x.Id.ToString(),
            });
            return selectListItems;
        }

        public IEnumerable<SelectListItem> GetAllCompanies()
        {
            var selectListItems = _context.Companies.OrderBy(x => x.CompanyName).Select(x => new SelectListItem
            {
                Text = string.Format("{0}{1}", x.CompanyName, !string.IsNullOrEmpty(x.Address) ? "," + x.Address : string.Empty),
                Value = x.Id.ToString(),
            });
            return selectListItems;
        }

        public IEnumerable<SelectListItem> GetAllJobRoles()
        {
            var selectListItems = _context.JobRoles.OrderBy(x => x.JobTitle).Select(x => new SelectListItem
            {
                Text = x.JobTitle,
                Value = x.Id.ToString(),
            });
            return selectListItems;
        }

        public IEnumerable<SelectListItem> GetAllBusinessTypes()
        {
            var selectListItems = _context.BusinessTypes.OrderBy(x => x.Type).Select(x => new SelectListItem
            {
                Text = x.Type,
                Value = x.Id.ToString(),
            });
            return selectListItems;
        }
    }
}
