﻿using JobPortal.Models;
using JobPortal.Services.IServices;
using JobPortal.ViewModels;

namespace JobPortal.Services
{
    public class FileService : IFileService
    {

        private readonly IWebHostEnvironment _environment;
        private readonly IHttpContextAccessor _httpContextAccessor;


        public FileService(IWebHostEnvironment environment, IHttpContextAccessor httpContextAccessor)
        {
            _environment = environment;
            _httpContextAccessor = httpContextAccessor;
        }

        public string GetUserCV(ApplicationUser user)
        {
            string filePath = Path.Combine(_environment.WebRootPath, "users", user.Id, user.ResumePath ?? "");
            if (File.Exists(filePath))
            {
                return GetBaseUrl() + $"/users/{user.Id}/{user.ResumePath}";
            }
            else
            {
                return string.Empty;
            }
        }

        public string GetUserProfile(ApplicationUser user)
        {
            string filePath = Path.Combine(_environment.WebRootPath, "users", user.Id, user.PhotoPath ?? "");
            if (File.Exists(filePath))
            {
                return GetBaseUrl() + $"/users/{user.Id}/{user.PhotoPath}";
            }
            else
            {
                return string.Empty;
            }
        }

        public async Task<string> UploadUserCVAsync(IFormFile file, ApplicationUser user)
        {

            var result = await SaveFileAsync(file, user.Id);

            if (result.Success)
            {
                string filePath = Path.Combine(_environment.WebRootPath, "users", user.Id, user.ResumePath ?? "");
                user.ResumePath = result.FileName;
                DeleteFile(filePath);
            }
            return result.FilePath;
        }

        public async Task<string> UploadUserProfileAsync(IFormFile file, ApplicationUser user)
        {
            var result = await SaveFileAsync(file, user.Id);
            if (result.Success)
            {
                string filePath = Path.Combine(_environment.WebRootPath, "users", user.Id, user.PhotoPath ?? "");
                user.PhotoPath = result.FileName;
                DeleteFile(filePath);
            }
            return result.FilePath;
        }

        private async Task<FileResult> SaveFileAsync(IFormFile file, string userId, string directory = "users")
        {

            var result = new FileResult();
            if (file == null)
            {
                result.Message = "Required File!";
                return result;
            }
            try
            {
                string extension = Path.GetExtension(file.FileName);

                string directoryPath = Path.Combine(_environment.WebRootPath, directory, userId);

                if (!Directory.Exists(directoryPath))
                {
                    Directory.CreateDirectory(directoryPath);
                }

                string fileName = Guid.NewGuid().ToString() + extension;

                string filePath = Path.Combine(directoryPath, fileName);

                using (var fileStream = new FileStream(filePath, FileMode.Create))
                {
                    await file.CopyToAsync(fileStream);
                }
                result.Success = true;
                result.FilePath = filePath;
                result.FileName = fileName;
            }
            catch (Exception ex)
            {
                result.Message = ex.Message;
                result.Success = false;
            }
            return result;
        }

        public string GetBaseUrl()
        {
            var request = _httpContextAccessor.HttpContext.Request;
            var baseUrl = $"{request.Scheme}://{request.Host}{request.PathBase}";
            return baseUrl;
        }

        public void DeleteFile(string filePath)
        {
            if (File.Exists(filePath))
            {
                try
                {
                    File.Delete(filePath);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"An error occurred while deleting the file: {ex.Message}");
                }
            }
        }

        public async Task<string> UploadCompanyLogoAsync(IFormFile file, Company company)
        {
            var result = await SaveFileAsync(file, company.Id.ToString(), "companies");

            if (result.Success)
            {
                string filePath = Path.Combine(_environment.WebRootPath, "users", company.Id.ToString(), company.CompanyLogoPath ?? "");
                company.CompanyLogoPath = result.FileName;
                DeleteFile(filePath);
            }
            return result.FilePath;
        }

        public string GetCompanyLogo(Company company)
        {
            string filePath = Path.Combine(_environment.WebRootPath, "companies", company.Id.ToString(), company.CompanyLogoPath ?? "");
            if (File.Exists(filePath))
            {
                return GetBaseUrl() + $"/companies/{company.Id}/{company.CompanyLogoPath}";
            }
            else
            {
                return string.Empty;
            }
        }
    }
}
