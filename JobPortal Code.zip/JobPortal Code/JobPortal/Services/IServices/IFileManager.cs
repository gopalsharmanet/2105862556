﻿using JobPortal.Models;

namespace JobPortal.Services.IServices
{
    public interface IFileService
    {
        Task<string> UploadCompanyLogoAsync(IFormFile file, Company company);
        Task<string> UploadUserProfileAsync(IFormFile file, ApplicationUser user);
        Task<string> UploadUserCVAsync(IFormFile file, ApplicationUser user);
        string GetUserProfile(ApplicationUser user);
        string GetUserCV(ApplicationUser user);
        string GetCompanyLogo(Company company);
    }
}
