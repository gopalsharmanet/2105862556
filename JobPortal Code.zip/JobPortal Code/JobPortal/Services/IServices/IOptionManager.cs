﻿using Microsoft.AspNetCore.Mvc.Rendering;

namespace JobPortal.Services.IServices
{
    public interface IOptionService
    {
        IEnumerable<SelectListItem> GetAllRoles();
        IEnumerable<SelectListItem> GetAllCities();
        IEnumerable<SelectListItem> GetAllSkills();
        IEnumerable<SelectListItem> GetAllCompanies();
        IEnumerable<SelectListItem> GetAllJobRoles();
        IEnumerable<SelectListItem> GetAllBusinessTypes();
    }
}
