﻿using System.Collections;

namespace JobPortal.Infrastructure
{
    public class AppConst
    {
        public const string Role_Admin = "Admin";
        public const string Role_JobSeeker = "JobSeeker";
        public const string Role_JobProvider = "JobProvider";
        public const string Temp_UserCVId = "UserCVId";
    }
    public class PartialViewConst
    {
        public const string PageTitle = "_PageTitle";
        public const string ChangePassword = "_ChangePassword";
        public const string SeekerProfileEdit = "_EditProfile";
        public const string SeekerExperience = "_SaveExperience";
        public const string SeekerEducation = "_SaveEducation";
        public const string ProfileOverview = "~/Views/JobSeeker/_ProfileOverview.cshtml";
        public const string SaveJobRole = "_SaveJobRole";
        public const string SaveCompany = "_SaveCompany";
        public const string JobSearchCriteria = "_JobSearchCriteria";
        public const string JobSummary = "_JobSummary";
        public const string ValidationScripts = "_ValidationScriptsPartial";
    }


    public static class Breadcrumb
    {
        public static readonly IEnumerable<(int Id, string Title, string Url)> JobSeekerProfile = new List<(int Id, string Title, string Url)>
        {
            (1, "Home", "/"),
            (2, "Profile", "/JobSeeker/Profile"),
        };

        public static readonly IEnumerable<(int Id, string Title, string Url)> ManageSkill = new List<(int Id, string Title, string Url)>
        {
            (1, "Home", "/"),
            (2, "Manage Skills", "/Skill"),
        }; 
        
        public static readonly IEnumerable<(int Id, string Title, string Url)> ManageJobRole = new List<(int Id, string Title, string Url)>
        {
            (1, "Home", "/"),
            (2, "Manage Job Role", "/JobRole"),
        };

        public static readonly IEnumerable<(int Id, string Title, string Url)> ManageBusinessType = new List<(int Id, string Title, string Url)>
        {
            (1, "Home", "/"),
            (2, "Manage Business Type", "/ManageBusinessType"),
        };

        public static readonly IEnumerable<(int Id, string Title, string Url)> ManageCompany = new List<(int Id, string Title, string Url)>
        {
            (1, "Home", "/"),
            (2, "Manage Company", "/ManageCompany"),
        };
    }
}
